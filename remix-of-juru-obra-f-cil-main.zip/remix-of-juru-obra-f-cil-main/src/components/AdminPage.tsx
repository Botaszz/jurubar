import { useState, useEffect } from 'react';
import { Button } from '@/components/ui/button';
import { Card, CardContent } from '@/components/ui/card';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Badge } from '@/components/ui/badge';
import { Input } from '@/components/ui/input';
import { Textarea } from '@/components/ui/textarea';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from '@/components/ui/dialog';
import { 
  Users, 
  FileText, 
  Key, 
  Check, 
  X, 
  RefreshCw, 
  Plus,
  Eye,
  Clock,
  CheckCircle,
  XCircle,
  AlertCircle,
  Pencil,
  Shield,
  ShieldCheck,
  ShieldX,
  Crown
} from 'lucide-react';
import { supabase } from '@/integrations/supabase/client';
import { useToast } from '@/hooks/use-toast';
import { useAuth } from '@/contexts/AuthContext';
import { SignatureCanvas } from './SignatureCanvas';

// Email do super admin (dono do sistema)
const SUPER_ADMIN_EMAIL = 'jotap4249@gmail.com';

interface Profile {
  id: string;
  user_id: string;
  email: string;
  full_name: string | null;
  is_approved: boolean;
  created_at: string;
}

interface Document {
  id: string;
  user_id: string;
  document_type: 'rdo' | 'cronograma' | 'hora_homem';
  title: string;
  content: unknown;
  status: 'pendente' | 'aprovado' | 'reprovado' | 'refazer';
  rejection_reason: string | null;
  obra_name: string | null;
  obra_location: string | null;
  created_at: string;
  profiles?: Profile;
}

interface RegistrationCode {
  id: string;
  code: string;
  is_active: boolean;
  used_by: string | null;
  created_at: string;
}

interface UserRole {
  user_id: string;
  role: 'admin' | 'user' | 'super_admin';
}

interface AdminPageProps {
  isSuperAdmin?: boolean;
}

export const AdminPage = ({ isSuperAdmin = false }: AdminPageProps) => {
  const { toast } = useToast();
  const { user, isAdmin } = useAuth();
  const [activeTab, setActiveTab] = useState(isSuperAdmin ? 'usuarios' : 'administradores');
  const [users, setUsers] = useState<Profile[]>([]);
  const [documents, setDocuments] = useState<Document[]>([]);
  const [codes, setCodes] = useState<RegistrationCode[]>([]);
  const [userRoles, setUserRoles] = useState<UserRole[]>([]);
  const [newCode, setNewCode] = useState('');
  const [codeDialogOpen, setCodeDialogOpen] = useState(false);
  const [reviewDialogOpen, setReviewDialogOpen] = useState(false);
  const [selectedDocument, setSelectedDocument] = useState<Document | null>(null);
  const [rejectionReason, setRejectionReason] = useState('');
  const [signatureDialogOpen, setSignatureDialogOpen] = useState(false);
  const [pendingAction, setPendingAction] = useState<'aprovar' | 'refazer' | 'reprovar' | null>(null);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    fetchData();
  }, []);

  const fetchData = async () => {
    setLoading(true);
    await Promise.all([fetchUsers(), fetchDocuments(), fetchCodes(), fetchUserRoles()]);
    setLoading(false);
  };

  const fetchUsers = async () => {
    const { data, error } = await supabase
      .from('profiles')
      .select('*')
      .order('created_at', { ascending: false });

    if (error) {
      if (import.meta.env.DEV) {
        console.error('Error fetching users:', error);
      }
      return;
    }
    setUsers(data || []);
  };

  const fetchDocuments = async () => {
    const { data, error } = await supabase
      .from('documents')
      .select('*')
      .order('created_at', { ascending: false });

    if (error) {
      if (import.meta.env.DEV) {
        console.error('Error fetching documents:', error);
      }
      return;
    }
    setDocuments((data || []) as Document[]);
  };

  const fetchCodes = async () => {
    const { data, error } = await supabase
      .from('registration_codes')
      .select('*')
      .order('created_at', { ascending: false });

    if (error) {
      if (import.meta.env.DEV) {
        console.error('Error fetching codes:', error);
      }
      return;
    }
    setCodes(data || []);
  };

  const fetchUserRoles = async () => {
    const { data, error } = await supabase
      .from('user_roles')
      .select('*');

    if (error) {
      if (import.meta.env.DEV) {
        console.error('Error fetching user roles:', error);
      }
      return;
    }
    setUserRoles((data || []) as UserRole[]);
  };

  const getUserRole = (userId: string): 'admin' | 'user' | 'super_admin' => {
    const userRole = userRoles.find(r => r.user_id === userId);
    return userRole?.role || 'user';
  };

  const isSuperAdminUser = (email: string): boolean => {
    return email === SUPER_ADMIN_EMAIL;
  };

  const handlePromoteToAdmin = async (userId: string) => {
    // Primeiro aprova o usuário se ainda não estiver aprovado
    const userProfile = users.find(u => u.user_id === userId);
    if (userProfile && !userProfile.is_approved) {
      await supabase
        .from('profiles')
        .update({ 
          is_approved: true,
          approved_by: user?.id,
          approved_at: new Date().toISOString()
        })
        .eq('user_id', userId);
    }

    const { error } = await supabase
      .from('user_roles')
      .update({ role: 'admin' })
      .eq('user_id', userId);

    if (error) {
      toast({
        title: 'Erro',
        description: 'Erro ao promover usuário a administrador',
        variant: 'destructive',
      });
      return;
    }

    toast({
      title: 'Sucesso',
      description: 'Usuário promovido a administrador!',
    });
    fetchData();
  };

  const handleRevokeAdmin = async (userId: string) => {
    const { error } = await supabase
      .from('user_roles')
      .update({ role: 'user' })
      .eq('user_id', userId);

    if (error) {
      toast({
        title: 'Erro',
        description: 'Erro ao revogar administrador',
        variant: 'destructive',
      });
      return;
    }

    toast({
      title: 'Sucesso',
      description: 'Administrador rebaixado para usuário!',
    });
    fetchData();
  };

  const handleApproveUser = async (userId: string) => {
    const { error } = await supabase
      .from('profiles')
      .update({ 
        is_approved: true,
        approved_by: user?.id,
        approved_at: new Date().toISOString()
      })
      .eq('user_id', userId);

    if (error) {
      toast({
        title: 'Erro',
        description: 'Erro ao aprovar usuário',
        variant: 'destructive',
      });
      return;
    }

    toast({
      title: 'Sucesso',
      description: 'Usuário aprovado!',
    });
    fetchUsers();
  };

  const handleRevokeUser = async (userId: string) => {
    const { error } = await supabase
      .from('profiles')
      .update({ 
        is_approved: false,
        approved_by: null,
        approved_at: null
      })
      .eq('user_id', userId);

    if (error) {
      toast({
        title: 'Erro',
        description: 'Erro ao revogar acesso do usuário',
        variant: 'destructive',
      });
      return;
    }

    toast({
      title: 'Sucesso',
      description: 'Acesso do usuário revogado!',
    });
    fetchUsers();
  };

  const handleCreateCode = async () => {
    if (!newCode.trim()) {
      toast({
        title: 'Erro',
        description: 'Digite um código válido',
        variant: 'destructive',
      });
      return;
    }

    const { error } = await supabase
      .from('registration_codes')
      .insert({
        code: newCode.trim().toUpperCase(),
        created_by: user?.id,
      });

    if (error) {
      toast({
        title: 'Erro',
        description: error.code === '23505' ? 'Código já existe' : 'Erro ao criar código',
        variant: 'destructive',
      });
      return;
    }

    toast({
      title: 'Sucesso',
      description: 'Código criado com sucesso!',
    });
    setNewCode('');
    setCodeDialogOpen(false);
    fetchCodes();
  };

  const handleDeleteCode = async (codeId: string) => {
    const { error } = await supabase
      .from('registration_codes')
      .delete()
      .eq('id', codeId);

    if (error) {
      toast({
        title: 'Erro',
        description: 'Erro ao deletar código',
        variant: 'destructive',
      });
      return;
    }

    toast({
      title: 'Sucesso',
      description: 'Código deletado',
    });
    fetchCodes();
  };

  const openReviewDialog = (doc: Document) => {
    setSelectedDocument(doc);
    setRejectionReason('');
    setReviewDialogOpen(true);
  };

  const handleDocumentAction = (action: 'aprovar' | 'refazer' | 'reprovar') => {
    setPendingAction(action);
    setReviewDialogOpen(false);
    setSignatureDialogOpen(true);
  };

  const handleSignatureSave = async (signatureData: string, signatureType: 'drawing' | 'upload') => {
    if (!selectedDocument || !pendingAction) return;

    const { data: signatureResult, error: signatureError } = await supabase
      .from('signatures')
      .insert([{
        user_id: user?.id,
        signature_type: signatureType,
        signature_data: signatureData,
      }])
      .select()
      .single();

    if (signatureError) {
      toast({
        title: 'Erro',
        description: 'Erro ao salvar assinatura',
        variant: 'destructive',
      });
      return;
    }

    const statusMap = {
      aprovar: 'aprovado' as const,
      refazer: 'refazer' as const,
      reprovar: 'reprovado' as const,
    };

    const { error } = await supabase
      .from('documents')
      .update({
        status: statusMap[pendingAction],
        rejection_reason: pendingAction !== 'aprovar' ? rejectionReason : null,
        reviewed_by: user?.id,
        reviewed_at: new Date().toISOString(),
        reviewer_signature_id: signatureResult.id,
      })
      .eq('id', selectedDocument.id);

    if (error) {
      toast({
        title: 'Erro',
        description: 'Erro ao atualizar documento',
        variant: 'destructive',
      });
      return;
    }

    toast({
      title: 'Sucesso',
      description: `Documento ${statusMap[pendingAction]}!`,
    });

    setSignatureDialogOpen(false);
    setPendingAction(null);
    setSelectedDocument(null);
    fetchDocuments();
  };

  const getStatusBadge = (status: string) => {
    const config = {
      pendente: { color: 'bg-warning/20 text-warning', icon: Clock },
      aprovado: { color: 'bg-success/20 text-success', icon: CheckCircle },
      reprovado: { color: 'bg-destructive/20 text-destructive', icon: XCircle },
      refazer: { color: 'bg-info/20 text-info', icon: AlertCircle },
    };

    const { color, icon: Icon } = config[status as keyof typeof config] || config.pendente;

    return (
      <Badge className={`${color} flex items-center gap-1`}>
        <Icon className="w-3 h-3" />
        {status.charAt(0).toUpperCase() + status.slice(1)}
      </Badge>
    );
  };

  const getDocumentTypeLabel = (type: string) => {
    const labels = {
      rdo: 'RDO',
      cronograma: 'Cronograma',
      hora_homem: 'Hora Homem',
    };
    return labels[type as keyof typeof labels] || type;
  };

  // Filtrar usuários normais (não admin e não super_admin)
  const normalUsers = users.filter(profile => {
    const role = getUserRole(profile.user_id);
    return role === 'user' && !isSuperAdminUser(profile.email);
  });

  // Filtrar administradores (admins, excluindo super_admin)
  const adminUsers = users.filter(profile => {
    const role = getUserRole(profile.user_id);
    return role === 'admin' && !isSuperAdminUser(profile.email);
  });

  // Super admin user
  const superAdminUser = users.find(profile => isSuperAdminUser(profile.email));

  if (loading) {
    return (
      <div className="flex items-center justify-center h-64">
        <RefreshCw className="w-8 h-8 animate-spin text-primary" />
      </div>
    );
  }

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <div className="flex items-center gap-3">
          <h1 className="text-2xl font-bold text-foreground">Painel Administrativo</h1>
          {isSuperAdmin && (
            <Badge className="bg-purple-500/20 text-purple-500 flex items-center gap-1">
              <Crown className="w-3 h-3" />
              Super Admin
            </Badge>
          )}
        </div>
        <Button variant="outline" onClick={fetchData}>
          <RefreshCw className="w-4 h-4 mr-2" />
          Atualizar
        </Button>
      </div>

      {/* Stats - Diferentes para super_admin e admin */}
      <div className={`grid grid-cols-1 ${isSuperAdmin ? 'md:grid-cols-4' : 'md:grid-cols-3'} gap-4`}>
        {isSuperAdmin && (
          <Card className="bg-card/50 border-border/50">
            <CardContent className="p-4">
              <div className="flex items-center gap-3">
                <div className="p-2 bg-primary/20 rounded-lg">
                  <Users className="w-5 h-5 text-primary" />
                </div>
                <div>
                  <p className="text-2xl font-bold text-foreground">{normalUsers.length}</p>
                  <p className="text-sm text-muted-foreground">Usuários</p>
                </div>
              </div>
            </CardContent>
          </Card>
        )}

        <Card className="bg-card/50 border-border/50">
          <CardContent className="p-4">
            <div className="flex items-center gap-3">
              <div className="p-2 bg-purple-500/20 rounded-lg">
                <Shield className="w-5 h-5 text-purple-500" />
              </div>
              <div>
                <p className="text-2xl font-bold text-foreground">{adminUsers.length}</p>
                <p className="text-sm text-muted-foreground">Administradores</p>
              </div>
            </div>
          </CardContent>
        </Card>

        <Card className="bg-card/50 border-border/50">
          <CardContent className="p-4">
            <div className="flex items-center gap-3">
              <div className="p-2 bg-warning/20 rounded-lg">
                <Clock className="w-5 h-5 text-warning" />
              </div>
              <div>
                <p className="text-2xl font-bold text-foreground">
                  {documents.filter(d => d.status === 'pendente').length}
                </p>
                <p className="text-sm text-muted-foreground">Docs Pendentes</p>
              </div>
            </div>
          </CardContent>
        </Card>

        {isSuperAdmin && (
          <Card className="bg-card/50 border-border/50">
            <CardContent className="p-4">
              <div className="flex items-center gap-3">
                <div className="p-2 bg-info/20 rounded-lg">
                  <Key className="w-5 h-5 text-info" />
                </div>
                <div>
                  <p className="text-2xl font-bold text-foreground">
                    {codes.filter(c => c.is_active && !c.used_by).length}
                  </p>
                  <p className="text-sm text-muted-foreground">Códigos Ativos</p>
                </div>
              </div>
            </CardContent>
          </Card>
        )}
      </div>

      <Tabs value={activeTab} onValueChange={setActiveTab}>
        <TabsList className="bg-secondary/50">
          {/* Aba Usuários - Somente Super Admin */}
          {isSuperAdmin && (
            <TabsTrigger value="usuarios">
              <Users className="w-4 h-4 mr-2" />
              Usuários
            </TabsTrigger>
          )}
          
          {/* Aba Administradores - Super Admin e Admins */}
          <TabsTrigger value="administradores">
            <Shield className="w-4 h-4 mr-2" />
            Administradores
          </TabsTrigger>
          
          {/* Aba Documentos - Super Admin e Admins */}
          <TabsTrigger value="documentos">
            <FileText className="w-4 h-4 mr-2" />
            Documentos
          </TabsTrigger>
          
          {/* Aba Códigos - Somente Super Admin */}
          {isSuperAdmin && (
            <TabsTrigger value="codigos">
              <Key className="w-4 h-4 mr-2" />
              Códigos
            </TabsTrigger>
          )}
        </TabsList>

        {/* Users Tab - Somente Super Admin */}
        {isSuperAdmin && (
          <TabsContent value="usuarios" className="space-y-4">
            {normalUsers.length === 0 ? (
              <Card className="bg-card/50 border-border/50">
                <CardContent className="p-8 text-center">
                  <Users className="w-12 h-12 mx-auto text-muted-foreground mb-4" />
                  <p className="text-muted-foreground">Nenhum usuário comum cadastrado</p>
                </CardContent>
              </Card>
            ) : (
              <div className="space-y-3">
                {normalUsers.map((profile) => (
                  <Card key={profile.id} className="bg-card/50 border-border/50">
                    <CardContent className="p-4">
                      <div className="flex items-center justify-between">
                        <div>
                          <p className="font-medium text-foreground">
                            {profile.full_name || 'Sem nome'}
                          </p>
                          <p className="text-sm text-muted-foreground">{profile.email}</p>
                          <p className="text-xs text-muted-foreground">
                            Cadastrado em: {new Date(profile.created_at).toLocaleDateString('pt-BR')}
                          </p>
                        </div>
                        <div className="flex items-center gap-2 flex-wrap justify-end">
                          <Badge className={profile.is_approved ? 'bg-success/20 text-success' : 'bg-warning/20 text-warning'}>
                            {profile.is_approved ? 'Aprovado' : 'Pendente'}
                          </Badge>
                          
                          {/* Botões de ação para usuários normais */}
                          {!profile.is_approved ? (
                            <Button
                              size="sm"
                              onClick={() => handleApproveUser(profile.user_id)}
                            >
                              <Check className="w-4 h-4 mr-1" />
                              Aprovar
                            </Button>
                          ) : (
                            <>
                              <Button
                                size="sm"
                                variant="outline"
                                onClick={() => handleRevokeUser(profile.user_id)}
                              >
                                <X className="w-4 h-4 mr-1" />
                                Revogar
                              </Button>
                              <Button
                                size="sm"
                                variant="secondary"
                                onClick={() => handlePromoteToAdmin(profile.user_id)}
                              >
                                <ShieldCheck className="w-4 h-4 mr-1" />
                                Tornar Admin
                              </Button>
                            </>
                          )}
                        </div>
                      </div>
                    </CardContent>
                  </Card>
                ))}
              </div>
            )}
          </TabsContent>
        )}

        {/* Administrators Tab - Super Admin e Admins podem ver */}
        <TabsContent value="administradores" className="space-y-4">
          {/* Super Admin Card */}
          {superAdminUser && (
            <Card className="bg-gradient-to-r from-purple-500/10 to-primary/10 border-purple-500/30">
              <CardContent className="p-4">
                <div className="flex items-center justify-between">
                  <div className="flex items-center gap-3">
                    <div className="p-2 bg-purple-500/20 rounded-full">
                      <Crown className="w-5 h-5 text-purple-500" />
                    </div>
                    <div>
                      <div className="flex items-center gap-2">
                        <p className="font-medium text-foreground">
                          {superAdminUser.full_name || 'Sem nome'}
                        </p>
                        <Badge className="bg-purple-500/20 text-purple-500">
                          Super Admin
                        </Badge>
                      </div>
                      <p className="text-sm text-muted-foreground">{superAdminUser.email}</p>
                      <p className="text-xs text-muted-foreground">
                        Dono do Sistema
                      </p>
                    </div>
                  </div>
                  <Badge className="bg-success/20 text-success">
                    Ativo
                  </Badge>
                </div>
              </CardContent>
            </Card>
          )}

          {adminUsers.length === 0 ? (
            <Card className="bg-card/50 border-border/50">
              <CardContent className="p-8 text-center">
                <Shield className="w-12 h-12 mx-auto text-muted-foreground mb-4" />
                <p className="text-muted-foreground">Nenhum administrador cadastrado</p>
              </CardContent>
            </Card>
          ) : (
            <div className="space-y-3">
              {adminUsers.map((profile) => (
                <Card key={profile.id} className="bg-card/50 border-border/50">
                  <CardContent className="p-4">
                    <div className="flex items-center justify-between">
                      <div className="flex items-center gap-3">
                        <div className="p-2 bg-primary/20 rounded-full">
                          <Shield className="w-5 h-5 text-primary" />
                        </div>
                        <div>
                          <div className="flex items-center gap-2">
                            <p className="font-medium text-foreground">
                              {profile.full_name || 'Sem nome'}
                            </p>
                            <Badge className="bg-primary/20 text-primary">Admin</Badge>
                          </div>
                          <p className="text-sm text-muted-foreground">{profile.email}</p>
                          <p className="text-xs text-muted-foreground">
                            Cadastrado em: {new Date(profile.created_at).toLocaleDateString('pt-BR')}
                          </p>
                        </div>
                      </div>
                      <div className="flex items-center gap-2">
                        <Badge className="bg-success/20 text-success">
                          Ativo
                        </Badge>
                        {/* Somente Super Admin pode revogar admin */}
                        {isSuperAdmin && (
                          <Button
                            size="sm"
                            variant="destructive"
                            onClick={() => handleRevokeAdmin(profile.user_id)}
                          >
                            <ShieldX className="w-4 h-4 mr-1" />
                            Revogar Admin
                          </Button>
                        )}
                      </div>
                    </div>
                  </CardContent>
                </Card>
              ))}
            </div>
          )}
        </TabsContent>

        {/* Documents Tab */}
        <TabsContent value="documentos" className="space-y-4">
          {documents.length === 0 ? (
            <Card className="bg-card/50 border-border/50">
              <CardContent className="p-8 text-center">
                <FileText className="w-12 h-12 mx-auto text-muted-foreground mb-4" />
                <p className="text-muted-foreground">Nenhum documento enviado</p>
              </CardContent>
            </Card>
          ) : (
            <div className="space-y-3">
              {documents.map((doc) => (
                <Card key={doc.id} className="bg-card/50 border-border/50">
                  <CardContent className="p-4">
                    <div className="flex items-center justify-between">
                      <div>
                        <div className="flex items-center gap-2 mb-1">
                          <Badge variant="outline">{getDocumentTypeLabel(doc.document_type)}</Badge>
                          {getStatusBadge(doc.status)}
                        </div>
                        <p className="font-medium text-foreground">{doc.title}</p>
                        {doc.obra_name && (
                          <p className="text-sm text-muted-foreground">
                            Obra: {doc.obra_name} - {doc.obra_location}
                          </p>
                        )}
                        <p className="text-xs text-muted-foreground">
                          Enviado em: {new Date(doc.created_at).toLocaleDateString('pt-BR')}
                        </p>
                        {doc.rejection_reason && (
                          <p className="text-sm text-destructive mt-1">
                            Motivo: {doc.rejection_reason}
                          </p>
                        )}
                      </div>
                      <div className="flex items-center gap-2">
                        <Button
                          size="sm"
                          variant="outline"
                          onClick={() => openReviewDialog(doc)}
                        >
                          <Eye className="w-4 h-4 mr-1" />
                          Revisar
                        </Button>
                      </div>
                    </div>
                  </CardContent>
                </Card>
              ))}
            </div>
          )}
        </TabsContent>

        {/* Codes Tab - Somente Super Admin */}
        {isSuperAdmin && (
          <TabsContent value="codigos" className="space-y-4">
            <div className="flex justify-end">
              <Dialog open={codeDialogOpen} onOpenChange={setCodeDialogOpen}>
                <DialogTrigger asChild>
                  <Button>
                    <Plus className="w-4 h-4 mr-2" />
                    Novo Código
                  </Button>
                </DialogTrigger>
                <DialogContent className="bg-card">
                  <DialogHeader>
                    <DialogTitle>Criar Código de Registro</DialogTitle>
                  </DialogHeader>
                  <div className="space-y-4">
                    <Input
                      placeholder="Digite o código (ex: JURUA2025)"
                      value={newCode}
                      onChange={(e) => setNewCode(e.target.value.toUpperCase())}
                      className="bg-secondary/50"
                    />
                    <Button onClick={handleCreateCode} className="w-full">
                      Criar Código
                    </Button>
                  </div>
                </DialogContent>
              </Dialog>
            </div>

            {codes.length === 0 ? (
              <Card className="bg-card/50 border-border/50">
                <CardContent className="p-8 text-center">
                  <Key className="w-12 h-12 mx-auto text-muted-foreground mb-4" />
                  <p className="text-muted-foreground">Nenhum código criado</p>
                </CardContent>
              </Card>
            ) : (
              <div className="space-y-3">
                {codes.map((code) => (
                  <Card key={code.id} className="bg-card/50 border-border/50">
                    <CardContent className="p-4">
                      <div className="flex items-center justify-between">
                        <div>
                          <p className="font-mono font-bold text-lg text-foreground">{code.code}</p>
                          <p className="text-xs text-muted-foreground">
                            Criado em: {new Date(code.created_at).toLocaleDateString('pt-BR')}
                          </p>
                        </div>
                        <div className="flex items-center gap-2">
                          <Badge className={code.used_by ? 'bg-muted text-muted-foreground' : 'bg-success/20 text-success'}>
                            {code.used_by ? 'Utilizado' : 'Disponível'}
                          </Badge>
                          {!code.used_by && (
                            <Button
                              size="sm"
                              variant="destructive"
                              onClick={() => handleDeleteCode(code.id)}
                            >
                              <X className="w-4 h-4" />
                            </Button>
                          )}
                        </div>
                      </div>
                    </CardContent>
                  </Card>
                ))}
              </div>
            )}
          </TabsContent>
        )}
      </Tabs>

      {/* Review Dialog */}
      <Dialog open={reviewDialogOpen} onOpenChange={setReviewDialogOpen}>
        <DialogContent className="bg-card max-w-2xl max-h-[80vh] overflow-y-auto">
          <DialogHeader>
            <DialogTitle>Revisar Documento</DialogTitle>
          </DialogHeader>
          {selectedDocument && (
            <div className="space-y-4">
              <div className="grid grid-cols-2 gap-4">
                <div>
                  <p className="text-sm text-muted-foreground">Tipo</p>
                  <p className="font-medium">{getDocumentTypeLabel(selectedDocument.document_type)}</p>
                </div>
                <div>
                  <p className="text-sm text-muted-foreground">Status</p>
                  {getStatusBadge(selectedDocument.status)}
                </div>
                <div>
                  <p className="text-sm text-muted-foreground">Título</p>
                  <p className="font-medium">{selectedDocument.title}</p>
                </div>
                <div>
                  <p className="text-sm text-muted-foreground">Obra</p>
                  <p className="font-medium">{selectedDocument.obra_name || '-'}</p>
                </div>
              </div>

              <div>
                <p className="text-sm text-muted-foreground mb-2">Conteúdo</p>
                <pre className="bg-secondary/50 p-4 rounded-lg text-sm overflow-x-auto">
                  {JSON.stringify(selectedDocument.content, null, 2)}
                </pre>
              </div>

              {selectedDocument.status !== 'aprovado' && (
                <>
                  <div>
                    <p className="text-sm text-muted-foreground mb-2">Motivo (para reprovação/refazer)</p>
                    <Textarea
                      value={rejectionReason}
                      onChange={(e) => setRejectionReason(e.target.value)}
                      placeholder="Digite o motivo..."
                      className="bg-secondary/50"
                    />
                  </div>

                  <div className="flex gap-2">
                    <Button
                      onClick={() => handleDocumentAction('aprovar')}
                      className="flex-1 bg-success hover:bg-success/90"
                    >
                      <Check className="w-4 h-4 mr-2" />
                      Aprovar
                    </Button>
                    <Button
                      onClick={() => handleDocumentAction('refazer')}
                      variant="outline"
                      className="flex-1"
                    >
                      <Pencil className="w-4 h-4 mr-2" />
                      Refazer
                    </Button>
                    <Button
                      onClick={() => handleDocumentAction('reprovar')}
                      variant="destructive"
                      className="flex-1"
                    >
                      <X className="w-4 h-4 mr-2" />
                      Reprovar
                    </Button>
                  </div>
                </>
              )}
            </div>
          )}
        </DialogContent>
      </Dialog>

      {/* Signature Dialog */}
      <Dialog open={signatureDialogOpen} onOpenChange={setSignatureDialogOpen}>
        <DialogContent className="bg-card">
          <DialogHeader>
            <DialogTitle>Assinar Revisão</DialogTitle>
          </DialogHeader>
          <SignatureCanvas
            onSave={handleSignatureSave}
            onCancel={() => {
              setSignatureDialogOpen(false);
              setPendingAction(null);
            }}
          />
        </DialogContent>
      </Dialog>
    </div>
  );
};

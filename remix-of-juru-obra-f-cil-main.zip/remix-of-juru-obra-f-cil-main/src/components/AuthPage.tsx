import { useState } from "react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Checkbox } from "@/components/ui/checkbox";
import { Anchor, Ship, Navigation, Compass } from "lucide-react";
import juruaLogo from "@/assets/jurua-logo.png";

interface AuthPageProps {
  onLogin: () => void;
}

const FloatingIcon = ({ 
  Icon, 
  className, 
  style 
}: { 
  Icon: React.ElementType; 
  className?: string; 
  style?: React.CSSProperties;
}) => (
  <div className={`absolute opacity-10 text-primary ${className}`} style={style}>
    <Icon className="w-full h-full" />
  </div>
);

export const AuthPage = ({ onLogin }: AuthPageProps) => {
  const [activeTab, setActiveTab] = useState<"login" | "cadastro">("login");
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [nome, setNome] = useState("");
  const [confirmPassword, setConfirmPassword] = useState("");
  const [rememberMe, setRememberMe] = useState(false);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    onLogin();
  };

  return (
    <div className="min-h-screen bg-background relative overflow-hidden flex flex-col items-center justify-center px-4">
      {/* Animated Background Objects */}
      <div className="absolute inset-0 pointer-events-none">
        {/* Ships */}
        <FloatingIcon 
          Icon={Ship} 
          className="w-24 h-24 animate-float-1" 
          style={{ top: '10%', left: '5%' }} 
        />
        <FloatingIcon 
          Icon={Ship} 
          className="w-16 h-16 animate-float-2" 
          style={{ top: '60%', right: '8%' }} 
        />
        <FloatingIcon 
          Icon={Ship} 
          className="w-20 h-20 animate-float-3" 
          style={{ bottom: '15%', left: '15%' }} 
        />
        
        {/* Anchors */}
        <FloatingIcon 
          Icon={Anchor} 
          className="w-20 h-20 animate-float-2" 
          style={{ top: '25%', right: '12%' }} 
        />
        <FloatingIcon 
          Icon={Anchor} 
          className="w-14 h-14 animate-float-1" 
          style={{ bottom: '30%', right: '25%' }} 
        />
        <FloatingIcon 
          Icon={Anchor} 
          className="w-18 h-18 animate-float-3" 
          style={{ top: '70%', left: '8%' }} 
        />
        
        {/* Navigation/Compass */}
        <FloatingIcon 
          Icon={Navigation} 
          className="w-16 h-16 animate-float-3" 
          style={{ top: '5%', right: '30%' }} 
        />
        <FloatingIcon 
          Icon={Compass} 
          className="w-22 h-22 animate-float-1" 
          style={{ bottom: '10%', right: '15%' }} 
        />
        <FloatingIcon 
          Icon={Compass} 
          className="w-12 h-12 animate-float-2" 
          style={{ top: '40%', left: '3%' }} 
        />
        
        {/* More scattered elements */}
        <FloatingIcon 
          Icon={Navigation} 
          className="w-10 h-10 animate-float-2" 
          style={{ bottom: '45%', left: '25%' }} 
        />
        <FloatingIcon 
          Icon={Ship} 
          className="w-14 h-14 animate-float-1" 
          style={{ top: '80%', right: '40%' }} 
        />
      </div>

      {/* Logo Section */}
      <div className="flex flex-col items-center mb-8 z-10">
        <div className="w-20 h-20 rounded-full overflow-hidden mb-4 shadow-lg border-4 border-primary">
          <img 
            src={juruaLogo} 
            alt="Juruá Logo" 
            className="w-full h-full object-cover scale-125"
          />
        </div>
        <h1 className="text-3xl font-bold text-foreground tracking-wide">JURUÁ</h1>
        <p className="text-primary text-sm tracking-widest mt-1">ESTALEIRO & NAVEGAÇÃO</p>
      </div>

      {/* Form Card */}
      <div className="w-full max-w-md bg-card/80 backdrop-blur-sm rounded-2xl p-6 z-10 border border-border/50">
        {/* Tabs */}
        <div className="flex mb-6 bg-secondary/50 rounded-xl p-1">
          <button
            onClick={() => setActiveTab("login")}
            className={`flex-1 py-2.5 rounded-lg text-sm font-medium transition-all ${
              activeTab === "login"
                ? "bg-primary text-primary-foreground"
                : "text-muted-foreground hover:text-foreground"
            }`}
          >
            Login
          </button>
          <button
            onClick={() => setActiveTab("cadastro")}
            className={`flex-1 py-2.5 rounded-lg text-sm font-medium transition-all ${
              activeTab === "cadastro"
                ? "bg-primary text-primary-foreground"
                : "text-muted-foreground hover:text-foreground"
            }`}
          >
            Cadastro
          </button>
        </div>

        <form onSubmit={handleSubmit} className="space-y-4">
          {activeTab === "cadastro" && (
            <div className="space-y-2">
              <Label htmlFor="nome" className="text-foreground">Nome</Label>
              <Input
                id="nome"
                type="text"
                placeholder="Seu nome completo"
                value={nome}
                onChange={(e) => setNome(e.target.value)}
                className="bg-secondary/50 border-border/50 text-foreground placeholder:text-muted-foreground"
              />
            </div>
          )}

          <div className="space-y-2">
            <Label htmlFor="email" className="text-foreground">Email</Label>
            <Input
              id="email"
              type="email"
              placeholder="seu@email.com"
              value={email}
              onChange={(e) => setEmail(e.target.value)}
              className="bg-secondary/50 border-border/50 text-foreground placeholder:text-muted-foreground"
            />
          </div>

          <div className="space-y-2">
            <Label htmlFor="password" className="text-foreground">Senha</Label>
            <Input
              id="password"
              type="password"
              placeholder="••••••••"
              value={password}
              onChange={(e) => setPassword(e.target.value)}
              className="bg-secondary/50 border-border/50 text-foreground placeholder:text-muted-foreground"
            />
          </div>

          {activeTab === "cadastro" && (
            <div className="space-y-2">
              <Label htmlFor="confirmPassword" className="text-foreground">Confirmar Senha</Label>
              <Input
                id="confirmPassword"
                type="password"
                placeholder="••••••••"
                value={confirmPassword}
                onChange={(e) => setConfirmPassword(e.target.value)}
                className="bg-secondary/50 border-border/50 text-foreground placeholder:text-muted-foreground"
              />
            </div>
          )}

          {activeTab === "login" && (
            <div className="flex items-center justify-between">
              <div className="flex items-center space-x-2">
                <Checkbox
                  id="remember"
                  checked={rememberMe}
                  onCheckedChange={(checked) => setRememberMe(checked as boolean)}
                  className="border-border/50 data-[state=checked]:bg-primary"
                />
                <Label htmlFor="remember" className="text-sm text-muted-foreground cursor-pointer">
                  Lembrar-me
                </Label>
              </div>
              <button type="button" className="text-sm text-primary hover:underline">
                Esqueceu a senha?
              </button>
            </div>
          )}

          <Button
            type="submit"
            className="w-full bg-primary hover:bg-primary/90 text-primary-foreground font-medium py-5"
          >
            {activeTab === "login" ? "Entrar" : "Cadastrar"}
          </Button>
        </form>

        {/* Divider */}
        <div className="flex items-center my-6">
          <div className="flex-1 h-px bg-border/50" />
          <span className="px-4 text-sm text-muted-foreground">ou continue com</span>
          <div className="flex-1 h-px bg-border/50" />
        </div>

        {/* Google Button */}
        <Button
          type="button"
          variant="outline"
          className="w-full border-border/50 bg-white hover:bg-gray-50 text-gray-700 font-medium py-5"
          onClick={() => onLogin()}
        >
          <svg className="w-5 h-5 mr-2" viewBox="0 0 24 24">
            <path
              fill="#4285F4"
              d="M22.56 12.25c0-.78-.07-1.53-.2-2.25H12v4.26h5.92c-.26 1.37-1.04 2.53-2.21 3.31v2.77h3.57c2.08-1.92 3.28-4.74 3.28-8.09z"
            />
            <path
              fill="#34A853"
              d="M12 23c2.97 0 5.46-.98 7.28-2.66l-3.57-2.77c-.98.66-2.23 1.06-3.71 1.06-2.86 0-5.29-1.93-6.16-4.53H2.18v2.84C3.99 20.53 7.7 23 12 23z"
            />
            <path
              fill="#FBBC05"
              d="M5.84 14.09c-.22-.66-.35-1.36-.35-2.09s.13-1.43.35-2.09V7.07H2.18C1.43 8.55 1 10.22 1 12s.43 3.45 1.18 4.93l2.85-2.22.81-.62z"
            />
            <path
              fill="#EA4335"
              d="M12 5.38c1.62 0 3.06.56 4.21 1.64l3.15-3.15C17.45 2.09 14.97 1 12 1 7.7 1 3.99 3.47 2.18 7.07l3.66 2.84c.87-2.6 3.3-4.53 6.16-4.53z"
            />
          </svg>
          Google
        </Button>
      </div>

      {/* Footer */}
      <p className="text-muted-foreground text-xs mt-8 z-10">
        © 2025 Juruá Estaleiro & Navegação. Todos os direitos reservados.
      </p>
    </div>
  );
};

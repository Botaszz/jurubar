import { useState } from "react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Checkbox } from "@/components/ui/checkbox";
import { Anchor, Ship, Navigation, Compass, Loader2 } from "lucide-react";
import { useAuth } from "@/contexts/AuthContext";
import { useToast } from "@/hooks/use-toast";
import juruaLogo from "@/assets/jurua-logo.png";
import { z } from "zod";

const FloatingIcon = ({
  Icon,
  className,
  style,
}: {
  Icon: React.ElementType;
  className?: string;
  style?: React.CSSProperties;
}) => (
  <div className={`absolute opacity-10 text-primary ${className}`} style={style}>
    <Icon className="w-full h-full" />
  </div>
);

const loginSchema = z.object({
  email: z.string().email("Email inválido"),
  password: z.string().min(6, "Senha deve ter pelo menos 6 caracteres"),
});

const signupSchema = z.object({
  nome: z.string().min(2, "Nome deve ter pelo menos 2 caracteres"),
  email: z.string().email("Email inválido"),
  password: z.string().min(6, "Senha deve ter pelo menos 6 caracteres"),
  confirmPassword: z.string(),
  registrationCode: z.string().min(1, "Código de registro é obrigatório"),
}).refine((data) => data.password === data.confirmPassword, {
  message: "As senhas não coincidem",
  path: ["confirmPassword"],
});

export const AuthPageNew = () => {
  const { signIn, signUp } = useAuth();
  const { toast } = useToast();
  const [activeTab, setActiveTab] = useState<"login" | "cadastro">("login");
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [nome, setNome] = useState("");
  const [confirmPassword, setConfirmPassword] = useState("");
  const [registrationCode, setRegistrationCode] = useState("");
  const [rememberMe, setRememberMe] = useState(false);
  const [loading, setLoading] = useState(false);
  const [errors, setErrors] = useState<Record<string, string>>({});

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setErrors({});
    setLoading(true);

    try {
      if (activeTab === "login") {
        const result = loginSchema.safeParse({ email, password });
        if (!result.success) {
          const fieldErrors: Record<string, string> = {};
          result.error.errors.forEach((err) => {
            if (err.path[0]) {
              fieldErrors[err.path[0] as string] = err.message;
            }
          });
          setErrors(fieldErrors);
          setLoading(false);
          return;
        }

        const { error } = await signIn(email, password);
        if (error) {
          toast({
            title: "Erro ao entrar",
            description: error.message === "Invalid login credentials"
              ? "Email ou senha incorretos"
              : error.message,
            variant: "destructive",
          });
        }
      } else {
        const result = signupSchema.safeParse({
          nome,
          email,
          password,
          confirmPassword,
          registrationCode,
        });

        if (!result.success) {
          const fieldErrors: Record<string, string> = {};
          result.error.errors.forEach((err) => {
            if (err.path[0]) {
              fieldErrors[err.path[0] as string] = err.message;
            }
          });
          setErrors(fieldErrors);
          setLoading(false);
          return;
        }

        const { error } = await signUp(email, password, nome, registrationCode);
        if (error) {
          toast({
            title: "Erro ao cadastrar",
            description: error.message,
            variant: "destructive",
          });
        } else {
          toast({
            title: "Cadastro realizado!",
            description: "Aguarde a aprovação do administrador para acessar o sistema.",
          });
        }
      }
    } catch (err) {
      toast({
        title: "Erro",
        description: "Ocorreu um erro inesperado",
        variant: "destructive",
      });
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="min-h-screen bg-background relative overflow-hidden flex flex-col items-center justify-center px-4">
      {/* Animated Background Objects */}
      <div className="absolute inset-0 pointer-events-none">
        <FloatingIcon Icon={Ship} className="w-24 h-24 animate-float-1" style={{ top: '10%', left: '5%' }} />
        <FloatingIcon Icon={Ship} className="w-16 h-16 animate-float-2" style={{ top: '60%', right: '8%' }} />
        <FloatingIcon Icon={Ship} className="w-20 h-20 animate-float-3" style={{ bottom: '15%', left: '15%' }} />
        <FloatingIcon Icon={Anchor} className="w-20 h-20 animate-float-2" style={{ top: '25%', right: '12%' }} />
        <FloatingIcon Icon={Anchor} className="w-14 h-14 animate-float-1" style={{ bottom: '30%', right: '25%' }} />
        <FloatingIcon Icon={Anchor} className="w-18 h-18 animate-float-3" style={{ top: '70%', left: '8%' }} />
        <FloatingIcon Icon={Navigation} className="w-16 h-16 animate-float-3" style={{ top: '5%', right: '30%' }} />
        <FloatingIcon Icon={Compass} className="w-22 h-22 animate-float-1" style={{ bottom: '10%', right: '15%' }} />
        <FloatingIcon Icon={Compass} className="w-12 h-12 animate-float-2" style={{ top: '40%', left: '3%' }} />
        <FloatingIcon Icon={Navigation} className="w-10 h-10 animate-float-2" style={{ bottom: '45%', left: '25%' }} />
        <FloatingIcon Icon={Ship} className="w-14 h-14 animate-float-1" style={{ top: '80%', right: '40%' }} />
      </div>

      {/* Logo Section */}
      <div className="flex flex-col items-center mb-8 z-10">
        <div className="w-20 h-20 rounded-full overflow-hidden mb-4 shadow-lg border-4 border-primary">
          <img src={juruaLogo} alt="Juruá Logo" className="w-full h-full object-cover scale-125" />
        </div>
        <h1 className="text-3xl font-bold text-foreground tracking-wide">JURUÁ</h1>
        <p className="text-primary text-sm tracking-widest mt-1">ESTALEIRO & NAVEGAÇÃO</p>
      </div>

      {/* Form Card */}
      <div className="w-full max-w-md bg-card/80 backdrop-blur-sm rounded-2xl p-6 z-10 border border-border/50">
        {/* Tabs */}
        <div className="flex mb-6 bg-secondary/50 rounded-xl p-1">
          <button
            onClick={() => setActiveTab("login")}
            className={`flex-1 py-2.5 rounded-lg text-sm font-medium transition-all ${
              activeTab === "login"
                ? "bg-primary text-primary-foreground"
                : "text-muted-foreground hover:text-foreground"
            }`}
          >
            Login
          </button>
          <button
            onClick={() => setActiveTab("cadastro")}
            className={`flex-1 py-2.5 rounded-lg text-sm font-medium transition-all ${
              activeTab === "cadastro"
                ? "bg-primary text-primary-foreground"
                : "text-muted-foreground hover:text-foreground"
            }`}
          >
            Cadastro
          </button>
        </div>

        <form onSubmit={handleSubmit} className="space-y-4">
          {activeTab === "cadastro" && (
            <>
              <div className="space-y-2">
                <Label htmlFor="registrationCode" className="text-foreground">
                  Código de Registro *
                </Label>
                <Input
                  id="registrationCode"
                  type="text"
                  placeholder="Digite o código fornecido"
                  value={registrationCode}
                  onChange={(e) => setRegistrationCode(e.target.value.toUpperCase())}
                  className="bg-secondary/50 border-border/50 text-foreground placeholder:text-muted-foreground"
                />
                {errors.registrationCode && (
                  <p className="text-sm text-destructive">{errors.registrationCode}</p>
                )}
              </div>

              <div className="space-y-2">
                <Label htmlFor="nome" className="text-foreground">Nome Completo</Label>
                <Input
                  id="nome"
                  type="text"
                  placeholder="Seu nome completo"
                  value={nome}
                  onChange={(e) => setNome(e.target.value)}
                  className="bg-secondary/50 border-border/50 text-foreground placeholder:text-muted-foreground"
                />
                {errors.nome && <p className="text-sm text-destructive">{errors.nome}</p>}
              </div>
            </>
          )}

          <div className="space-y-2">
            <Label htmlFor="email" className="text-foreground">Email</Label>
            <Input
              id="email"
              type="email"
              placeholder="seu@email.com"
              value={email}
              onChange={(e) => setEmail(e.target.value)}
              className="bg-secondary/50 border-border/50 text-foreground placeholder:text-muted-foreground"
            />
            {errors.email && <p className="text-sm text-destructive">{errors.email}</p>}
          </div>

          <div className="space-y-2">
            <Label htmlFor="password" className="text-foreground">Senha</Label>
            <Input
              id="password"
              type="password"
              placeholder="••••••••"
              value={password}
              onChange={(e) => setPassword(e.target.value)}
              className="bg-secondary/50 border-border/50 text-foreground placeholder:text-muted-foreground"
            />
            {errors.password && <p className="text-sm text-destructive">{errors.password}</p>}
          </div>

          {activeTab === "cadastro" && (
            <div className="space-y-2">
              <Label htmlFor="confirmPassword" className="text-foreground">Confirmar Senha</Label>
              <Input
                id="confirmPassword"
                type="password"
                placeholder="••••••••"
                value={confirmPassword}
                onChange={(e) => setConfirmPassword(e.target.value)}
                className="bg-secondary/50 border-border/50 text-foreground placeholder:text-muted-foreground"
              />
              {errors.confirmPassword && (
                <p className="text-sm text-destructive">{errors.confirmPassword}</p>
              )}
            </div>
          )}

          {activeTab === "login" && (
            <div className="flex items-center justify-between">
              <div className="flex items-center space-x-2">
                <Checkbox
                  id="remember"
                  checked={rememberMe}
                  onCheckedChange={(checked) => setRememberMe(checked as boolean)}
                  className="border-border/50 data-[state=checked]:bg-primary"
                />
                <Label htmlFor="remember" className="text-sm text-muted-foreground cursor-pointer">
                  Lembrar-me
                </Label>
              </div>
              <button type="button" className="text-sm text-primary hover:underline">
                Esqueceu a senha?
              </button>
            </div>
          )}

          <Button
            type="submit"
            disabled={loading}
            className="w-full bg-primary hover:bg-primary/90 text-primary-foreground font-medium py-5"
          >
            {loading ? (
              <>
                <Loader2 className="w-4 h-4 mr-2 animate-spin" />
                Aguarde...
              </>
            ) : (
              activeTab === "login" ? "Entrar" : "Cadastrar"
            )}
          </Button>
        </form>
      </div>

      {/* Footer */}
      <p className="text-muted-foreground text-xs mt-8 z-10">
        © 2025 Juruá Estaleiro & Navegação. Todos os direitos reservados.
      </p>
    </div>
  );
};

import { useState } from "react";
import { Plus, Trash2 } from "lucide-react";
import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Progress } from "@/components/ui/progress";
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from "@/components/ui/dialog";
import {
  Popover,
  PopoverContent,
  PopoverTrigger,
} from "@/components/ui/popover";
import { Calendar } from "@/components/ui/calendar";
import { Slider } from "@/components/ui/slider";
import { CronogramaItem } from "@/types/rdo";
import { format } from "date-fns";
import { ptBR } from "date-fns/locale";
import { cn } from "@/lib/utils";
import { useToast } from "@/hooks/use-toast";
import { CalendarDays } from "lucide-react";

interface CronogramaPageProps {
  cronograma: CronogramaItem[];
  setCronograma: (items: CronogramaItem[]) => void;
}

export const CronogramaPage = ({ cronograma, setCronograma }: CronogramaPageProps) => {
  const { toast } = useToast();
  const [dialogOpen, setDialogOpen] = useState(false);
  const [dateInicio, setDateInicio] = useState<Date>();
  const [dateFim, setDateFim] = useState<Date>();
  
  const [formData, setFormData] = useState({
    atividade: "",
    responsavel: "",
    status: "pendente" as const,
    progresso: 0,
  });

  const handleCreate = () => {
    if (!formData.atividade || !dateInicio || !dateFim) {
      toast({ title: "Erro", description: "Preencha os campos obrigatórios", variant: "destructive" });
      return;
    }

    const newItem: CronogramaItem = {
      id: Date.now().toString(),
      atividade: formData.atividade,
      dataInicio: format(dateInicio, "dd/MM/yyyy"),
      dataFim: format(dateFim, "dd/MM/yyyy"),
      responsavel: formData.responsavel,
      status: formData.status,
      progresso: formData.progresso,
    };

    setCronograma([...cronograma, newItem]);
    setDialogOpen(false);
    resetForm();
    toast({ title: "Sucesso!", description: "Atividade adicionada" });
  };

  const resetForm = () => {
    setFormData({ atividade: "", responsavel: "", status: "pendente", progresso: 0 });
    setDateInicio(undefined);
    setDateFim(undefined);
  };

  const handleDelete = (id: string) => {
    setCronograma(cronograma.filter(item => item.id !== id));
    toast({ title: "Removido" });
  };

  const handleProgressChange = (id: string, progress: number) => {
    setCronograma(cronograma.map(item => 
      item.id === id 
        ? { 
            ...item, 
            progresso: progress,
            status: progress === 100 ? 'concluido' : progress > 0 ? 'em_andamento' : 'pendente'
          }
        : item
    ));
  };

  const getStatusColor = (status: string) => {
    switch (status) {
      case 'concluido': return 'bg-emerald-500/10 text-emerald-400';
      case 'em_andamento': return 'bg-amber-500/10 text-amber-400';
      default: return 'bg-secondary text-muted-foreground';
    }
  };

  const getStatusLabel = (status: string) => {
    switch (status) {
      case 'concluido': return 'Concluído';
      case 'em_andamento': return 'Em Andamento';
      default: return 'Pendente';
    }
  };

  const progressoTotal = cronograma.length > 0 
    ? Math.round(cronograma.reduce((acc, item) => acc + item.progresso, 0) / cronograma.length)
    : 0;

  return (
    <div className="space-y-4 animate-fade-in pb-20 md:pb-0">
      {/* Header */}
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-2xl font-bold text-foreground">Cronograma</h1>
          <p className="text-muted-foreground text-sm">Atividades do projeto</p>
        </div>
        
        <Dialog open={dialogOpen} onOpenChange={setDialogOpen}>
          <DialogTrigger asChild>
            <Button size="sm" className="bg-primary text-primary-foreground hover:bg-primary/90 rounded-xl touch-manipulation">
              <Plus className="w-4 h-4 mr-1.5" />
              Nova
            </Button>
          </DialogTrigger>
          <DialogContent className="glass-dark border-border/30 mx-3">
            <DialogHeader>
              <DialogTitle className="text-lg font-bold text-foreground">Nova Atividade</DialogTitle>
            </DialogHeader>
            
            <div className="space-y-4 py-2">
              <div className="space-y-1.5">
                <Label className="text-foreground text-xs">Atividade *</Label>
                <Input
                  placeholder="Nome da atividade"
                  value={formData.atividade}
                  onChange={(e) => setFormData({ ...formData, atividade: e.target.value })}
                  className="bg-secondary/50 border-border/30 h-10"
                />
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div className="space-y-1.5">
                  <Label className="text-foreground text-xs">Data Início *</Label>
                  <Popover>
                    <PopoverTrigger asChild>
                      <Button
                        variant="outline"
                        className={cn(
                          "w-full justify-start text-left font-normal bg-secondary/50 border-border/30 h-10 text-sm",
                          !dateInicio && "text-muted-foreground"
                        )}
                      >
                        <CalendarDays className="w-4 h-4 mr-2 opacity-50" />
                        {dateInicio ? format(dateInicio, "dd/MM/yy", { locale: ptBR }) : "Selecione"}
                      </Button>
                    </PopoverTrigger>
                    <PopoverContent className="w-auto p-0 glass-dark border-border/30" align="start">
                      <Calendar mode="single" selected={dateInicio} onSelect={setDateInicio} locale={ptBR} className="pointer-events-auto" />
                    </PopoverContent>
                  </Popover>
                </div>
                
                <div className="space-y-1.5">
                  <Label className="text-foreground text-xs">Data Fim *</Label>
                  <Popover>
                    <PopoverTrigger asChild>
                      <Button
                        variant="outline"
                        className={cn(
                          "w-full justify-start text-left font-normal bg-secondary/50 border-border/30 h-10 text-sm",
                          !dateFim && "text-muted-foreground"
                        )}
                      >
                        <CalendarDays className="w-4 h-4 mr-2 opacity-50" />
                        {dateFim ? format(dateFim, "dd/MM/yy", { locale: ptBR }) : "Selecione"}
                      </Button>
                    </PopoverTrigger>
                    <PopoverContent className="w-auto p-0 glass-dark border-border/30" align="start">
                      <Calendar mode="single" selected={dateFim} onSelect={setDateFim} locale={ptBR} className="pointer-events-auto" />
                    </PopoverContent>
                  </Popover>
                </div>
              </div>

              <div className="space-y-1.5">
                <Label className="text-foreground text-xs">Responsável</Label>
                <Input
                  placeholder="Nome"
                  value={formData.responsavel}
                  onChange={(e) => setFormData({ ...formData, responsavel: e.target.value })}
                  className="bg-secondary/50 border-border/30 h-10"
                />
              </div>

              <div className="space-y-2">
                <div className="flex justify-between items-center">
                  <Label className="text-foreground text-xs">Progresso</Label>
                  <span className="text-sm font-bold text-primary">{formData.progresso}%</span>
                </div>
                <Slider
                  value={[formData.progresso]}
                  onValueChange={([value]) => setFormData({ ...formData, progresso: value })}
                  max={100}
                  step={5}
                  className="py-2"
                />
              </div>

              <Button 
                onClick={handleCreate}
                className="w-full bg-primary text-primary-foreground hover:bg-primary/90 h-11 rounded-xl"
              >
                Adicionar
              </Button>
            </div>
          </DialogContent>
        </Dialog>
      </div>

      {/* Progress Overview */}
      <Card className="glass-effect border-border/30">
        <CardContent className="p-4">
          <div className="flex items-center justify-between mb-3">
            <span className="text-foreground text-sm font-medium">Progresso Geral</span>
            <span className="text-xl font-bold text-primary">{progressoTotal}%</span>
          </div>
          <Progress value={progressoTotal} className="h-2" />
        </CardContent>
      </Card>

      {/* Activities List */}
      {cronograma.length === 0 ? (
        <Card className="glass-effect border-border/30">
          <CardContent className="py-12 text-center">
            <div className="w-14 h-14 mx-auto mb-3 rounded-2xl bg-primary/10 flex items-center justify-center">
              <Plus className="w-7 h-7 text-primary" />
            </div>
            <h3 className="text-lg font-semibold text-foreground mb-1">Nenhuma atividade</h3>
            <p className="text-muted-foreground text-sm">Adicione atividades ao cronograma</p>
          </CardContent>
        </Card>
      ) : (
        <div className="space-y-3">
          {cronograma.map((item, index) => (
            <Card 
              key={item.id}
              className="glass-effect border-border/30 overflow-hidden transition-all duration-200 active:scale-[0.99] touch-manipulation"
              style={{ animationDelay: `${index * 50}ms` }}
            >
              <CardContent className="p-4">
                <div className="flex items-start justify-between mb-3">
                  <div>
                    <h3 className="font-semibold text-foreground text-sm">{item.atividade}</h3>
                    <p className="text-xs text-muted-foreground">{item.responsavel || "Sem responsável"}</p>
                  </div>
                  <div className="flex items-center gap-2">
                    <span className={cn("px-2 py-1 rounded-lg text-[10px] font-medium", getStatusColor(item.status))}>
                      {getStatusLabel(item.status)}
                    </span>
                    <Button
                      size="icon"
                      variant="ghost"
                      onClick={() => handleDelete(item.id)}
                      className="w-8 h-8 text-destructive hover:bg-destructive/10"
                    >
                      <Trash2 className="w-3.5 h-3.5" />
                    </Button>
                  </div>
                </div>

                <div className="flex items-center gap-3 text-xs text-muted-foreground mb-3">
                  <span>{item.dataInicio}</span>
                  <span>→</span>
                  <span>{item.dataFim}</span>
                </div>

                <div className="space-y-2">
                  <div className="flex items-center justify-between">
                    <span className="text-xs text-muted-foreground">Avanço</span>
                    <span className="text-sm font-bold text-primary">{item.progresso}%</span>
                  </div>
                  <Slider
                    value={[item.progresso]}
                    onValueChange={([value]) => handleProgressChange(item.id, value)}
                    max={100}
                    step={5}
                    className="py-1"
                  />
                </div>
              </CardContent>
            </Card>
          ))}
        </div>
      )}
    </div>
  );
};

import { FileText, Calendar, Clock, TrendingUp } from "lucide-react";
import { Card, CardContent } from "@/components/ui/card";
import { RDOData, CronogramaItem, ObraHH } from "@/types/rdo";

interface DashboardProps {
  rdos: RDOData[];
  cronograma: CronogramaItem[];
  obras: ObraHH[];
}

export const Dashboard = ({ rdos, cronograma, obras }: DashboardProps) => {
  const totalHH = obras.reduce((acc, obra) => 
    acc + obra.registros.reduce((a, r) => a + r.totalHH, 0), 0
  );
  const progressoMedio = cronograma.length > 0 
    ? Math.round(cronograma.reduce((acc, c) => acc + c.progresso, 0) / cronograma.length)
    : 0;

  const stats = [
    {
      title: "RDOs",
      value: rdos.length,
      icon: FileText,
      gradient: "from-primary/20 to-accent/20",
      iconBg: "bg-primary/10",
      iconColor: "text-primary",
    },
    {
      title: "Atividades",
      value: cronograma.length,
      icon: Calendar,
      gradient: "from-emerald-500/20 to-teal-500/20",
      iconBg: "bg-emerald-500/10",
      iconColor: "text-emerald-400",
    },
    {
      title: "Total HH",
      value: `${Math.round(totalHH)}h`,
      icon: Clock,
      gradient: "from-violet-500/20 to-purple-500/20",
      iconBg: "bg-violet-500/10",
      iconColor: "text-violet-400",
    },
    {
      title: "Progresso",
      value: `${progressoMedio}%`,
      icon: TrendingUp,
      gradient: "from-rose-500/20 to-pink-500/20",
      iconBg: "bg-rose-500/10",
      iconColor: "text-rose-400",
    },
  ];

  // Calculate HH by category from obras - using totalHH which is already calculated per person
  const montadorHH = obras.reduce((acc, obra) => 
    acc + obra.registros.filter(r => r.categoria === 'montador-ajudante').reduce((a, r) => {
      const horasDecimal = r.horas + (r.minutos / 60);
      return a + (r.montadores * horasDecimal);
    }, 0), 0
  );
  const ajudanteHH = obras.reduce((acc, obra) => 
    acc + obra.registros.filter(r => r.categoria === 'montador-ajudante').reduce((a, r) => {
      const horasDecimal = r.horas + (r.minutos / 60);
      return a + (r.ajudantes * horasDecimal);
    }, 0), 0
  );
  const soldadorHH = obras.reduce((acc, obra) => 
    acc + obra.registros.filter(r => r.categoria === 'soldador-lixador').reduce((a, r) => {
      const horasDecimal = r.horas + (r.minutos / 60);
      return a + (r.soldadores * horasDecimal);
    }, 0), 0
  );
  const lixadorHH = obras.reduce((acc, obra) => 
    acc + obra.registros.filter(r => r.categoria === 'soldador-lixador').reduce((a, r) => {
      const horasDecimal = r.horas + (r.minutos / 60);
      return a + (r.lixadores * horasDecimal);
    }, 0), 0
  );

  const formatHH = (value: number) => {
    const hours = Math.floor(value);
    const minutes = Math.round((value - hours) * 60);
    return minutes > 0 ? `${hours}h ${minutes}min` : `${hours}h`;
  };

  return (
    <div className="space-y-5 animate-fade-in pb-20 md:pb-0">
      {/* Welcome Section */}
      <div className="relative overflow-hidden rounded-2xl bg-gradient-to-br from-primary/10 via-card to-secondary p-5 md:p-8">
        <div className="absolute top-0 right-0 w-48 h-48 bg-primary/5 rounded-full blur-3xl -translate-y-1/2 translate-x-1/2" />
        <div className="relative z-10">
          <h1 className="text-2xl md:text-3xl font-bold text-foreground mb-1">
            Bem-vindo ao <span className="text-gradient">Juruá</span>
          </h1>
          <p className="text-muted-foreground text-sm md:text-base">
            Gestão de Obras, Cronograma e Hora Homem
          </p>
        </div>
      </div>

      {/* Stats Grid */}
      <div className="grid grid-cols-2 lg:grid-cols-4 gap-3">
        {stats.map((stat, index) => (
          <Card 
            key={stat.title}
            className={`glass-effect border-border/30 overflow-hidden transition-all duration-300 hover:scale-[1.02] active:scale-[0.98] touch-manipulation`}
            style={{ animationDelay: `${index * 50}ms` }}
          >
            <CardContent className="p-4">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-muted-foreground text-xs font-medium uppercase tracking-wide">{stat.title}</p>
                  <p className="text-2xl md:text-3xl font-bold text-foreground mt-1">{stat.value}</p>
                </div>
                <div className={`p-2.5 rounded-xl ${stat.iconBg}`}>
                  <stat.icon className={`w-5 h-5 ${stat.iconColor}`} />
                </div>
              </div>
            </CardContent>
          </Card>
        ))}
      </div>

      {/* Recent Activity */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-4">
        {/* Recent RDOs */}
        <Card className="glass-effect border-border/30">
          <CardContent className="p-4">
            <div className="flex items-center gap-2 mb-4">
              <FileText className="w-4 h-4 text-primary" />
              <h3 className="font-semibold text-foreground text-sm">RDOs Recentes</h3>
            </div>
            {rdos.length === 0 ? (
              <p className="text-muted-foreground text-sm text-center py-6">
                Nenhum RDO criado
              </p>
            ) : (
              <div className="space-y-2">
                {rdos.slice(0, 4).map((rdo) => (
                  <div 
                    key={rdo.id}
                    className="flex items-center justify-between p-3 rounded-xl bg-secondary/30"
                  >
                    <div>
                      <p className="font-medium text-foreground text-sm">{rdo.obra}</p>
                      <p className="text-xs text-muted-foreground">{rdo.dataApresentacao}</p>
                    </div>
                    <div className="w-2 h-2 rounded-full bg-primary" />
                  </div>
                ))}
              </div>
            )}
          </CardContent>
        </Card>

        {/* Cronograma Progress */}
        <Card className="glass-effect border-border/30">
          <CardContent className="p-4">
            <div className="flex items-center gap-2 mb-4">
              <Calendar className="w-4 h-4 text-primary" />
              <h3 className="font-semibold text-foreground text-sm">Progresso</h3>
            </div>
            {cronograma.length === 0 ? (
              <p className="text-muted-foreground text-sm text-center py-6">
                Nenhuma atividade
              </p>
            ) : (
              <div className="space-y-3">
                {cronograma.slice(0, 4).map((item) => (
                  <div key={item.id} className="space-y-1.5">
                    <div className="flex items-center justify-between">
                      <span className="text-xs font-medium text-foreground truncate max-w-[70%]">{item.atividade}</span>
                      <span className="text-xs font-bold text-primary">{item.progresso}%</span>
                    </div>
                    <div className="h-1.5 bg-secondary rounded-full overflow-hidden">
                      <div 
                        className="h-full bg-gradient-to-r from-primary to-accent rounded-full transition-all duration-500"
                        style={{ width: `${item.progresso}%` }}
                      />
                    </div>
                  </div>
                ))}
              </div>
            )}
          </CardContent>
        </Card>
      </div>

      {/* HH Summary */}
      <Card className="glass-effect border-border/30">
        <CardContent className="p-4">
          <div className="flex items-center gap-2 mb-4">
            <Clock className="w-4 h-4 text-primary" />
            <h3 className="font-semibold text-foreground text-sm">Hora Homem</h3>
          </div>
          {obras.length === 0 ? (
            <p className="text-muted-foreground text-sm text-center py-6">
              Nenhum registro
            </p>
          ) : (
            <div className="grid grid-cols-2 md:grid-cols-4 gap-3">
              <div className="p-3 rounded-xl bg-primary/10 text-center">
                <p className="text-xl font-bold text-primary">{formatHH(montadorHH)}</p>
                <p className="text-xs text-muted-foreground mt-0.5">Montadores</p>
              </div>
              <div className="p-3 rounded-xl bg-emerald-500/10 text-center">
                <p className="text-xl font-bold text-emerald-400">{formatHH(ajudanteHH)}</p>
                <p className="text-xs text-muted-foreground mt-0.5">Ajudantes</p>
              </div>
              <div className="p-3 rounded-xl bg-amber-500/10 text-center">
                <p className="text-xl font-bold text-amber-400">{formatHH(soldadorHH)}</p>
                <p className="text-xs text-muted-foreground mt-0.5">Soldadores</p>
              </div>
              <div className="p-3 rounded-xl bg-violet-500/10 text-center">
                <p className="text-xl font-bold text-violet-400">{formatHH(lixadorHH)}</p>
                <p className="text-xs text-muted-foreground mt-0.5">Lixadores</p>
              </div>
            </div>
          )}
        </CardContent>
      </Card>
    </div>
  );
};

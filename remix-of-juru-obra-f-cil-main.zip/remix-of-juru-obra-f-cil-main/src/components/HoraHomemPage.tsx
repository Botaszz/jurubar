import { useState } from "react";
import { Plus, Trash2, Clock, TrendingUp, FolderOpen, FileText, Download, Send } from "lucide-react";
import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table";
import { ObraHH, HHRegistro } from "@/types/rdo";
import { useToast } from "@/hooks/use-toast";
import { useAuth } from "@/contexts/AuthContext";
import { supabase } from "@/integrations/supabase/client";
import { SignatureCanvas } from "./SignatureCanvas";

interface HoraHomemPageProps {
  obras: ObraHH[];
  setObras: (data: ObraHH[]) => void;
}

export const HoraHomemPage = ({ obras, setObras }: HoraHomemPageProps) => {
  const { toast } = useToast();
  const { user, isApproved } = useAuth();
  const [obraDialogOpen, setObraDialogOpen] = useState(false);
  const [registroDialogOpen, setRegistroDialogOpen] = useState(false);
  const [submitDialogOpen, setSubmitDialogOpen] = useState(false);
  const [signatureDialogOpen, setSignatureDialogOpen] = useState(false);
  const [activeObraId, setActiveObraId] = useState<string | null>(null);
  const [activeCategoria, setActiveCategoria] = useState<'montador-ajudante' | 'soldador-lixador'>('montador-ajudante');
  const [submitting, setSubmitting] = useState(false);
  
  // Nova Obra form
  const [novaObra, setNovaObra] = useState({ nome: '', local: '' });
  
  // Novo Registro form with hours and minutes
  const [novoRegistro, setNovoRegistro] = useState({
    data: '',
    horas: 8,
    minutos: 0,
    montadores: 0,
    ajudantes: 0,
    soldadores: 0,
    lixadores: 0,
    atividade: '',
    local: ''
  });

  const activeObra = obras.find(o => o.id === activeObraId);

  // Format hours and minutes to display string
  const formatHH = (horas: number, minutos: number) => {
    if (minutos === 0) return `${horas}h`;
    return `${horas}h ${minutos}min`;
  };

  // Calculate decimal hours from hours and minutes
  const toDecimalHours = (horas: number, minutos: number) => {
    return horas + (minutos / 60);
  };

  const handleCreateObra = () => {
    if (!novaObra.nome || !novaObra.local) {
      toast({ title: "Erro", description: "Preencha todos os campos", variant: "destructive" });
      return;
    }

    const newObra: ObraHH = {
      id: Date.now().toString(),
      nome: novaObra.nome,
      local: novaObra.local,
      registros: [],
      createdAt: new Date()
    };

    setObras([...obras, newObra]);
    setActiveObraId(newObra.id);
    setObraDialogOpen(false);
    setNovaObra({ nome: '', local: '' });
    toast({ title: "Sucesso!", description: "Obra criada" });
  };

  const handleCreateRegistro = () => {
    if (!activeObraId || !novoRegistro.data) {
      toast({ title: "Erro", description: "Preencha a data", variant: "destructive" });
      return;
    }

    const horasDecimal = toDecimalHours(novoRegistro.horas, novoRegistro.minutos);
    const pessoas = activeCategoria === 'montador-ajudante'
      ? novoRegistro.montadores + novoRegistro.ajudantes
      : novoRegistro.soldadores + novoRegistro.lixadores;
    const totalHH = pessoas * horasDecimal;

    const newRegistro: HHRegistro = {
      id: Date.now().toString(),
      data: novoRegistro.data,
      horas: novoRegistro.horas,
      minutos: novoRegistro.minutos,
      montadores: activeCategoria === 'montador-ajudante' ? novoRegistro.montadores : 0,
      ajudantes: activeCategoria === 'montador-ajudante' ? novoRegistro.ajudantes : 0,
      soldadores: activeCategoria === 'soldador-lixador' ? novoRegistro.soldadores : 0,
      lixadores: activeCategoria === 'soldador-lixador' ? novoRegistro.lixadores : 0,
      totalHH,
      totalHHFormatted: formatHH(Math.floor(totalHH), Math.round((totalHH % 1) * 60)),
      atividade: novoRegistro.atividade,
      local: novoRegistro.local,
      categoria: activeCategoria
    };

    setObras(obras.map(o => 
      o.id === activeObraId 
        ? { ...o, registros: [...o.registros, newRegistro] }
        : o
    ));
    
    setRegistroDialogOpen(false);
    setNovoRegistro({
      data: '',
      horas: 8,
      minutos: 0,
      montadores: 0,
      ajudantes: 0,
      soldadores: 0,
      lixadores: 0,
      atividade: '',
      local: ''
    });
    toast({ title: "Sucesso!", description: "Registro adicionado" });
  };

  const handleDeleteRegistro = (registroId: string) => {
    if (!activeObraId) return;
    setObras(obras.map(o => 
      o.id === activeObraId 
        ? { ...o, registros: o.registros.filter(r => r.id !== registroId) }
        : o
    ));
    toast({ title: "Registro removido" });
  };

  const handleSubmitForApproval = async (signatureData: string, signatureType: 'drawing' | 'upload') => {
    if (!activeObra || !user) return;
    
    setSubmitting(true);
    try {
      // Save signature
      const { data: signatureResult, error: signatureError } = await supabase
        .from('signatures')
        .insert([{
          user_id: user.id,
          signature_type: signatureType,
          signature_data: signatureData,
        }])
        .select()
        .single();

      if (signatureError) throw signatureError;

      // Submit document for approval
      const { data: docResult, error: docError } = await supabase
        .from('documents')
        .insert([{
          user_id: user.id,
          document_type: 'hora_homem' as const,
          title: `HH - ${activeObra.nome}`,
          content: JSON.parse(JSON.stringify({
            obra: activeObra,
            registros: activeObra.registros,
          })),
          status: 'pendente' as const,
          obra_name: activeObra.nome,
          obra_location: activeObra.local,
          author_signature_id: signatureResult.id,
        }])
        .select()
        .single();

      if (docError) throw docError;

      // Update local state
      setObras(obras.map(o => 
        o.id === activeObraId 
          ? { ...o, status: 'pendente', documentId: docResult.id }
          : o
      ));

      toast({ title: "Sucesso!", description: "Hora Homem enviado para aprovação" });
      setSignatureDialogOpen(false);
      setSubmitDialogOpen(false);
    } catch (error) {
      console.error('Error submitting:', error);
      toast({ title: "Erro", description: "Erro ao enviar para aprovação", variant: "destructive" });
    } finally {
      setSubmitting(false);
    }
  };

  const getObraStats = (obra: ObraHH, categoria: 'montador-ajudante' | 'soldador-lixador') => {
    const registros = obra.registros.filter(r => r.categoria === categoria);
    const totalHH = registros.reduce((acc, r) => acc + r.totalHH, 0);
    const mediaHHDia = registros.length > 0 ? Math.round(totalHH / registros.length) : 0;
    return { totalHH, mediaHHDia, totalRegistros: registros.length };
  };

  const horasDecimal = toDecimalHours(novoRegistro.horas, novoRegistro.minutos);
  const pessoas = activeCategoria === 'montador-ajudante'
    ? novoRegistro.montadores + novoRegistro.ajudantes
    : novoRegistro.soldadores + novoRegistro.lixadores;
  const calculatedTotalHH = pessoas * horasDecimal;

  // Empty state - no obras
  if (obras.length === 0) {
    return (
      <div className="space-y-4 animate-fade-in pb-20 md:pb-0">
        <div className="flex items-center justify-between">
          <div>
            <h1 className="text-2xl font-bold text-foreground">Hora Homem (HH)</h1>
            <p className="text-muted-foreground text-sm">Controle de horas trabalhadas por categoria e obra</p>
          </div>
          <Button 
            onClick={() => setObraDialogOpen(true)}
            className="bg-violet-600 hover:bg-violet-700 text-white rounded-xl"
          >
            <FileText className="w-4 h-4 mr-2" />
            Nova Obra
          </Button>
        </div>

        <Card className="glass-effect border-border/30">
          <CardContent className="py-16 text-center">
            <div className="w-16 h-16 mx-auto mb-4 rounded-full bg-muted/30 flex items-center justify-center">
              <Clock className="w-8 h-8 text-muted-foreground" />
            </div>
            <h3 className="text-xl font-semibold text-foreground mb-2">Nenhuma Obra Cadastrada</h3>
            <p className="text-muted-foreground text-sm mb-6">Comece criando sua primeira obra para gerenciar Hora Homem</p>
            <Button 
              onClick={() => setObraDialogOpen(true)}
              className="bg-primary hover:bg-primary/90 text-primary-foreground rounded-xl"
            >
              <Plus className="w-4 h-4 mr-2" />
              Criar Primeira Obra
            </Button>
          </CardContent>
        </Card>

        {/* Dialog Criar Obra */}
        <Dialog open={obraDialogOpen} onOpenChange={setObraDialogOpen}>
          <DialogContent className="max-w-md glass-dark border-border/30">
            <DialogHeader>
              <DialogTitle className="text-lg font-bold text-foreground flex items-center gap-2">
                <FileText className="w-5 h-5 text-primary" />
                Criar Nova Obra
              </DialogTitle>
            </DialogHeader>
            <div className="space-y-4 py-2">
              <div className="space-y-2">
                <Label className="text-foreground text-sm">Nome da Obra</Label>
                <Input
                  placeholder="Ex: Construção de Galpão"
                  value={novaObra.nome}
                  onChange={(e) => setNovaObra({ ...novaObra, nome: e.target.value })}
                  className="bg-secondary/50 border-border/30 h-11"
                />
              </div>
              <div className="space-y-2">
                <Label className="text-foreground text-sm">Local da Obra</Label>
                <Input
                  placeholder="Ex: Refinaria Juruá - Setor D"
                  value={novaObra.local}
                  onChange={(e) => setNovaObra({ ...novaObra, local: e.target.value })}
                  className="bg-secondary/50 border-border/30 h-11"
                />
              </div>
              <div className="flex gap-3 pt-2">
                <Button
                  variant="outline"
                  onClick={() => setObraDialogOpen(false)}
                  className="flex-1 border-border/30"
                >
                  Cancelar
                </Button>
                <Button 
                  onClick={handleCreateObra}
                  className="flex-1 bg-primary hover:bg-primary/90 text-primary-foreground"
                >
                  Criar Obra
                </Button>
              </div>
            </div>
          </DialogContent>
        </Dialog>
      </div>
    );
  }

  // Set active obra if none selected
  if (!activeObraId && obras.length > 0) {
    setActiveObraId(obras[obras.length - 1].id);
  }

  const stats = activeObra ? getObraStats(activeObra, activeCategoria) : { totalHH: 0, mediaHHDia: 0, totalRegistros: 0 };
  const filteredRegistros = activeObra?.registros.filter(r => r.categoria === activeCategoria) || [];

  return (
    <div className="space-y-4 animate-fade-in pb-20 md:pb-0">
      {/* Header */}
      <div className="flex items-center justify-between flex-wrap gap-3">
        <div>
          <h1 className="text-2xl font-bold text-foreground">Hora Homem (HH)</h1>
          <p className="text-muted-foreground text-sm">Controle de horas trabalhadas por categoria e obra</p>
        </div>
        <div className="flex gap-2 flex-wrap">
          {isApproved && activeObra && (
            <Button 
              onClick={() => setSubmitDialogOpen(true)}
              className="bg-green-600 hover:bg-green-700 text-white rounded-xl"
            >
              <Send className="w-4 h-4 mr-2" />
              Enviar para Aprovação
            </Button>
          )}
          <Button className="bg-emerald-600 hover:bg-emerald-700 text-white rounded-xl">
            <Download className="w-4 h-4 mr-2" />
            Exportar PDF
          </Button>
          <Button 
            onClick={() => setRegistroDialogOpen(true)}
            className="bg-primary hover:bg-primary/90 text-primary-foreground rounded-xl border border-primary/50"
          >
            <Plus className="w-4 h-4 mr-2" />
            Novo Registro HH
          </Button>
          <Button 
            onClick={() => setObraDialogOpen(true)}
            className="bg-violet-600 hover:bg-violet-700 text-white rounded-xl"
          >
            <FileText className="w-4 h-4 mr-2" />
            Nova Obra
          </Button>
        </div>
      </div>

      {/* Obra Tabs */}
      <div className="flex gap-2 flex-wrap">
        {obras.map(obra => (
          <Button
            key={obra.id}
            variant={activeObraId === obra.id ? "default" : "outline"}
            onClick={() => setActiveObraId(obra.id)}
            className={`rounded-xl ${activeObraId === obra.id ? 'bg-primary text-primary-foreground' : 'border-border/30 bg-muted/30'}`}
          >
            <FileText className="w-4 h-4 mr-2" />
            <div className="text-left">
              <div className="font-semibold text-sm">{obra.nome}</div>
              <div className="text-xs opacity-70">{obra.local}</div>
            </div>
          </Button>
        ))}
      </div>

      {/* Active Obra Header */}
      {activeObra && (
        <Card className="glass-effect border-border/30">
          <CardContent className="p-4 flex items-center gap-3">
            <FolderOpen className="w-5 h-5 text-primary" />
            <div>
              <h2 className="font-bold text-foreground">{activeObra.nome}</h2>
              <p className="text-muted-foreground text-sm">{activeObra.local}</p>
            </div>
          </CardContent>
        </Card>
      )}

      {/* Category Tabs */}
      <Tabs value={activeCategoria} onValueChange={(v) => setActiveCategoria(v as any)} className="w-full">
        <TabsList className="bg-muted/30 h-10 p-1">
          <TabsTrigger 
            value="montador-ajudante" 
            className="rounded-xl data-[state=active]:bg-primary data-[state=active]:text-primary-foreground"
          >
            Montador & Ajudante
          </TabsTrigger>
          <TabsTrigger 
            value="soldador-lixador"
            className="rounded-xl data-[state=active]:bg-muted data-[state=active]:text-foreground"
          >
            Soldador & Lixador
          </TabsTrigger>
        </TabsList>

        <TabsContent value={activeCategoria} className="mt-4 space-y-4">
          {/* Stats Cards */}
          <div className="grid grid-cols-3 gap-4">
            <Card className="glass-effect border-border/30">
              <CardContent className="p-4">
                <div className="flex items-center justify-between mb-2">
                  <span className="text-muted-foreground text-sm">Total HH</span>
                  <TrendingUp className="w-5 h-5 text-primary" />
                </div>
                <p className="text-3xl font-bold text-foreground">
                  {formatHH(Math.floor(stats.totalHH), Math.round((stats.totalHH % 1) * 60))}
                </p>
              </CardContent>
            </Card>
            <Card className="glass-effect border-border/30">
              <CardContent className="p-4">
                <div className="flex items-center justify-between mb-2">
                  <span className="text-muted-foreground text-sm">Média HH/Dia</span>
                  <Clock className="w-5 h-5 text-green-500" />
                </div>
                <p className="text-3xl font-bold text-foreground">
                  {formatHH(Math.floor(stats.mediaHHDia), Math.round((stats.mediaHHDia % 1) * 60))}
                </p>
              </CardContent>
            </Card>
            <Card className="glass-effect border-border/30">
              <CardContent className="p-4">
                <div className="flex items-center justify-between mb-2">
                  <span className="text-muted-foreground text-sm">Total Registros</span>
                  <Clock className="w-5 h-5 text-violet-500" />
                </div>
                <p className="text-3xl font-bold text-foreground">{stats.totalRegistros}</p>
              </CardContent>
            </Card>
          </div>

          {/* Records Table or Empty State */}
          {filteredRegistros.length === 0 ? (
            <Card className="glass-effect border-border/30">
              <CardContent className="py-16 text-center">
                <div className="w-16 h-16 mx-auto mb-4 rounded-full bg-muted/30 flex items-center justify-center">
                  <Clock className="w-8 h-8 text-muted-foreground" />
                </div>
                <h3 className="text-lg font-semibold text-foreground mb-2">Nenhum registro de HH para esta categoria</h3>
                <p className="text-muted-foreground text-sm mb-6">Adicione registros de hora homem para esta obra</p>
                <Button 
                  onClick={() => setRegistroDialogOpen(true)}
                  className="bg-primary hover:bg-primary/90 text-primary-foreground rounded-xl"
                >
                  <Plus className="w-4 h-4 mr-2" />
                  Adicionar Primeiro Registro
                </Button>
              </CardContent>
            </Card>
          ) : (
            <Card className="glass-effect border-border/30 overflow-hidden">
              <Table>
                <TableHeader>
                  <TableRow className="border-border/30 hover:bg-transparent">
                    <TableHead className="text-muted-foreground">Data</TableHead>
                    {activeCategoria === 'montador-ajudante' ? (
                      <>
                        <TableHead className="text-muted-foreground">Montadores</TableHead>
                        <TableHead className="text-muted-foreground">Ajudantes</TableHead>
                      </>
                    ) : (
                      <>
                        <TableHead className="text-muted-foreground">Soldadores</TableHead>
                        <TableHead className="text-muted-foreground">Lixadores</TableHead>
                      </>
                    )}
                    <TableHead className="text-muted-foreground">Tempo/Pessoa</TableHead>
                    <TableHead className="text-muted-foreground">Total HH</TableHead>
                    <TableHead className="text-muted-foreground">Atividade</TableHead>
                    <TableHead className="text-muted-foreground">Local</TableHead>
                    <TableHead className="text-muted-foreground">Ações</TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {filteredRegistros.map((registro) => (
                    <TableRow key={registro.id} className="border-border/30">
                      <TableCell className="font-medium text-foreground">
                        {new Date(registro.data).toLocaleDateString('pt-BR')}
                      </TableCell>
                      {activeCategoria === 'montador-ajudante' ? (
                        <>
                          <TableCell className="text-foreground">{registro.montadores}</TableCell>
                          <TableCell className="text-foreground">{registro.ajudantes}</TableCell>
                        </>
                      ) : (
                        <>
                          <TableCell className="text-foreground">{registro.soldadores}</TableCell>
                          <TableCell className="text-foreground">{registro.lixadores}</TableCell>
                        </>
                      )}
                      <TableCell className="text-foreground">
                        {formatHH(registro.horas, registro.minutos)}
                      </TableCell>
                      <TableCell>
                        <span className="px-3 py-1 rounded-full text-sm font-medium bg-primary/20 text-primary border border-primary/30">
                          {registro.totalHHFormatted || formatHH(Math.floor(registro.totalHH), Math.round((registro.totalHH % 1) * 60))}
                        </span>
                      </TableCell>
                      <TableCell className="text-foreground">{registro.atividade}</TableCell>
                      <TableCell className="text-foreground">{registro.local}</TableCell>
                      <TableCell>
                        <Button
                          size="icon"
                          variant="ghost"
                          onClick={() => handleDeleteRegistro(registro.id)}
                          className="w-8 h-8 text-destructive hover:bg-destructive/10"
                        >
                          <Trash2 className="w-4 h-4" />
                        </Button>
                      </TableCell>
                    </TableRow>
                  ))}
                </TableBody>
              </Table>
            </Card>
          )}
        </TabsContent>
      </Tabs>

      {/* Dialog Criar Obra */}
      <Dialog open={obraDialogOpen} onOpenChange={setObraDialogOpen}>
        <DialogContent className="max-w-md glass-dark border-border/30">
          <DialogHeader>
            <DialogTitle className="text-lg font-bold text-foreground flex items-center gap-2">
              <FileText className="w-5 h-5 text-primary" />
              Criar Nova Obra
            </DialogTitle>
          </DialogHeader>
          <div className="space-y-4 py-2">
            <div className="space-y-2">
              <Label className="text-foreground text-sm">Nome da Obra</Label>
              <Input
                placeholder="Ex: Construção de Galpão"
                value={novaObra.nome}
                onChange={(e) => setNovaObra({ ...novaObra, nome: e.target.value })}
                className="bg-secondary/50 border-border/30 h-11"
              />
            </div>
            <div className="space-y-2">
              <Label className="text-foreground text-sm">Local da Obra</Label>
              <Input
                placeholder="Ex: Refinaria Juruá - Setor D"
                value={novaObra.local}
                onChange={(e) => setNovaObra({ ...novaObra, local: e.target.value })}
                className="bg-secondary/50 border-border/30 h-11"
              />
            </div>
            <div className="flex gap-3 pt-2">
              <Button
                variant="outline"
                onClick={() => setObraDialogOpen(false)}
                className="flex-1 border-border/30"
              >
                Cancelar
              </Button>
              <Button 
                onClick={handleCreateObra}
                className="flex-1 bg-primary hover:bg-primary/90 text-primary-foreground"
              >
                Criar Obra
              </Button>
            </div>
          </div>
        </DialogContent>
      </Dialog>

      {/* Dialog Novo Registro */}
      <Dialog open={registroDialogOpen} onOpenChange={setRegistroDialogOpen}>
        <DialogContent className="max-w-lg glass-dark border-border/30">
          <DialogHeader>
            <DialogTitle className="text-lg font-bold text-foreground">
              Novo Registro HH - {activeCategoria === 'montador-ajudante' ? 'Montador & Ajudante' : 'Soldador & Lixador'}
            </DialogTitle>
          </DialogHeader>
          <div className="space-y-4 py-2">
            <div className="space-y-2">
              <Label className="text-foreground text-sm">Data</Label>
              <Input
                type="date"
                value={novoRegistro.data}
                onChange={(e) => setNovoRegistro({ ...novoRegistro, data: e.target.value })}
                className="bg-secondary/50 border-border/30 h-11"
              />
            </div>

            {/* Hours and Minutes Input */}
            <div className="space-y-2">
              <Label className="text-foreground text-sm">Tempo por Pessoa</Label>
              <div className="grid grid-cols-2 gap-4">
                <div className="space-y-1">
                  <Label className="text-muted-foreground text-xs">Horas</Label>
                  <Input
                    type="number"
                    min="0"
                    max="24"
                    value={novoRegistro.horas}
                    onChange={(e) => setNovoRegistro({ ...novoRegistro, horas: Number(e.target.value) })}
                    className="bg-secondary/50 border-border/30 h-11"
                  />
                </div>
                <div className="space-y-1">
                  <Label className="text-muted-foreground text-xs">Minutos</Label>
                  <Input
                    type="number"
                    min="0"
                    max="59"
                    step="5"
                    value={novoRegistro.minutos}
                    onChange={(e) => setNovoRegistro({ ...novoRegistro, minutos: Number(e.target.value) })}
                    className="bg-secondary/50 border-border/30 h-11"
                  />
                </div>
              </div>
            </div>

            <div className="grid grid-cols-2 gap-4">
              {activeCategoria === 'montador-ajudante' ? (
                <>
                  <div className="space-y-2">
                    <Label className="text-foreground text-sm">Quantidade de Montadores</Label>
                    <Input
                      type="number"
                      min="0"
                      value={novoRegistro.montadores}
                      onChange={(e) => setNovoRegistro({ ...novoRegistro, montadores: Number(e.target.value) })}
                      className="bg-secondary/50 border-border/30 h-11"
                    />
                  </div>
                  <div className="space-y-2">
                    <Label className="text-foreground text-sm">Quantidade de Ajudantes</Label>
                    <Input
                      type="number"
                      min="0"
                      value={novoRegistro.ajudantes}
                      onChange={(e) => setNovoRegistro({ ...novoRegistro, ajudantes: Number(e.target.value) })}
                      className="bg-secondary/50 border-border/30 h-11"
                    />
                  </div>
                </>
              ) : (
                <>
                  <div className="space-y-2">
                    <Label className="text-foreground text-sm">Quantidade de Soldadores</Label>
                    <Input
                      type="number"
                      min="0"
                      value={novoRegistro.soldadores}
                      onChange={(e) => setNovoRegistro({ ...novoRegistro, soldadores: Number(e.target.value) })}
                      className="bg-secondary/50 border-border/30 h-11"
                    />
                  </div>
                  <div className="space-y-2">
                    <Label className="text-foreground text-sm">Quantidade de Lixadores</Label>
                    <Input
                      type="number"
                      min="0"
                      value={novoRegistro.lixadores}
                      onChange={(e) => setNovoRegistro({ ...novoRegistro, lixadores: Number(e.target.value) })}
                      className="bg-secondary/50 border-border/30 h-11"
                    />
                  </div>
                </>
              )}
            </div>

            {/* Total HH Calculado */}
            <Card className="bg-primary/10 border-primary/30">
              <CardContent className="p-4">
                <p className="text-primary text-sm font-medium">Total HH Calculado:</p>
                <p className="text-2xl font-bold text-foreground">
                  {formatHH(Math.floor(calculatedTotalHH), Math.round((calculatedTotalHH % 1) * 60))}
                </p>
              </CardContent>
            </Card>

            <div className="space-y-2">
              <Label className="text-foreground text-sm">Atividade</Label>
              <Input
                placeholder="Descreva a atividade realizada"
                value={novoRegistro.atividade}
                onChange={(e) => setNovoRegistro({ ...novoRegistro, atividade: e.target.value })}
                className="bg-secondary/50 border-border/30 h-11"
              />
            </div>

            <div className="space-y-2">
              <Label className="text-foreground text-sm">Local</Label>
              <Input
                placeholder="Local onde a atividade foi realizada"
                value={novoRegistro.local}
                onChange={(e) => setNovoRegistro({ ...novoRegistro, local: e.target.value })}
                className="bg-secondary/50 border-border/30 h-11"
              />
            </div>

            <div className="flex gap-3 pt-2">
              <Button
                variant="outline"
                onClick={() => setRegistroDialogOpen(false)}
                className="flex-1 border-border/30"
              >
                Cancelar
              </Button>
              <Button 
                onClick={handleCreateRegistro}
                className="flex-1 bg-primary hover:bg-primary/90 text-primary-foreground"
              >
                Adicionar Registro
              </Button>
            </div>
          </div>
        </DialogContent>
      </Dialog>

      {/* Submit for Approval Dialog */}
      <Dialog open={submitDialogOpen} onOpenChange={setSubmitDialogOpen}>
        <DialogContent className="glass-dark border-border/30">
          <DialogHeader>
            <DialogTitle className="text-lg font-bold text-foreground">
              Enviar para Aprovação
            </DialogTitle>
          </DialogHeader>
          <div className="space-y-4 py-2">
            <p className="text-muted-foreground">
              Você está prestes a enviar os registros de Hora Homem da obra <strong className="text-foreground">{activeObra?.nome}</strong> para aprovação do administrador.
            </p>
            <p className="text-muted-foreground text-sm">
              Após o envio, você precisará assinar digitalmente o documento.
            </p>
            <div className="flex gap-3 pt-2">
              <Button
                variant="outline"
                onClick={() => setSubmitDialogOpen(false)}
                className="flex-1 border-border/30"
              >
                Cancelar
              </Button>
              <Button 
                onClick={() => {
                  setSubmitDialogOpen(false);
                  setSignatureDialogOpen(true);
                }}
                className="flex-1 bg-primary hover:bg-primary/90 text-primary-foreground"
              >
                Continuar
              </Button>
            </div>
          </div>
        </DialogContent>
      </Dialog>

      {/* Signature Dialog */}
      <Dialog open={signatureDialogOpen} onOpenChange={setSignatureDialogOpen}>
        <DialogContent className="glass-dark border-border/30">
          <DialogHeader>
            <DialogTitle className="text-lg font-bold text-foreground">
              Assinatura do Responsável
            </DialogTitle>
          </DialogHeader>
          <SignatureCanvas
            onSave={handleSubmitForApproval}
            onCancel={() => setSignatureDialogOpen(false)}
          />
        </DialogContent>
      </Dialog>
    </div>
  );
};

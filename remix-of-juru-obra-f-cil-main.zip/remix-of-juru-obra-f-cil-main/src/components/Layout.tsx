import { ReactNode, useState } from "react";
import { Logo } from "./Logo";
import { 
  FileText, 
  Calendar, 
  Clock, 
  LayoutDashboard,
  Menu,
  X,
  Shield,
  LogOut
} from "lucide-react";
import { cn } from "@/lib/utils";
import { useAuth } from "@/contexts/AuthContext";
import { Button } from "./ui/button";

interface LayoutProps {
  children: ReactNode;
  activeTab: string;
  onTabChange: (tab: string) => void;
  isAdmin?: boolean;
}

const getNavItems = (isAdmin: boolean) => {
  const items = [
    { id: "dashboard", label: "Dashboard", icon: LayoutDashboard },
    { id: "rdo", label: "RDO", icon: FileText },
    { id: "cronograma", label: "Cronograma", icon: Calendar },
    { id: "hora-homem", label: "HH", icon: Clock },
  ];
  
  if (isAdmin) {
    items.push({ id: "admin", label: "Admin", icon: Shield });
  }
  
  return items;
};

export const Layout = ({ children, activeTab, onTabChange, isAdmin = false }: LayoutProps) => {
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);
  const { signOut } = useAuth();
  const navItems = getNavItems(isAdmin);

  return (
    <div className="min-h-screen bg-background">
      {/* Header */}
      <header className="fixed top-0 left-0 right-0 z-50 glass-effect">
        <div className="container mx-auto px-4 h-14 md:h-16 flex items-center justify-between">
          <Logo />
          
          {/* Desktop Navigation */}
          <nav className="hidden md:flex items-center gap-1">
            {navItems.map((item) => (
              <button
                key={item.id}
                onClick={() => onTabChange(item.id)}
                className={cn(
                  "flex items-center gap-2 px-4 py-2 rounded-xl text-sm font-medium transition-all duration-200",
                  activeTab === item.id
                    ? "bg-primary text-primary-foreground"
                    : "text-muted-foreground hover:text-foreground hover:bg-secondary/50"
                )}
              >
                <item.icon className="w-4 h-4" />
                {item.label}
              </button>
            ))}
            <Button variant="ghost" size="sm" onClick={signOut} className="ml-2">
              <LogOut className="w-4 h-4" />
            </Button>
          </nav>

          {/* Mobile Menu Button */}
          <button
            onClick={() => setMobileMenuOpen(!mobileMenuOpen)}
            className="md:hidden p-2 rounded-xl hover:bg-secondary/50 transition-colors touch-manipulation"
          >
            {mobileMenuOpen ? <X className="w-5 h-5" /> : <Menu className="w-5 h-5" />}
          </button>
        </div>

        {/* Mobile Navigation */}
        {mobileMenuOpen && (
          <nav className="md:hidden glass-effect border-t border-border/30 p-3 animate-slide-up">
            <div className="grid grid-cols-5 gap-2">
              {navItems.map((item) => (
                <button
                  key={item.id}
                  onClick={() => {
                    onTabChange(item.id);
                    setMobileMenuOpen(false);
                  }}
                  className={cn(
                    "flex flex-col items-center gap-1.5 p-3 rounded-xl text-xs font-medium transition-all duration-200 touch-manipulation",
                    activeTab === item.id
                      ? "bg-primary text-primary-foreground"
                      : "text-muted-foreground hover:text-foreground hover:bg-secondary/50"
                  )}
                >
                  <item.icon className="w-5 h-5" />
                  {item.label}
                </button>
              ))}
            </div>
          </nav>
        )}
      </header>

      {/* Main Content */}
      <main className="pt-16 md:pt-20 pb-20 md:pb-6 px-3 md:px-4">
        <div className="container mx-auto max-w-6xl">
          {children}
        </div>
      </main>

      {/* Bottom Navigation for Mobile */}
      <nav className="md:hidden fixed bottom-0 left-0 right-0 glass-effect border-t border-border/30 safe-area-inset-bottom">
        <div className={cn("grid gap-1 p-2", isAdmin ? "grid-cols-5" : "grid-cols-4")}>
          {navItems.map((item) => (
            <button
              key={item.id}
              onClick={() => onTabChange(item.id)}
              className={cn(
                "flex flex-col items-center gap-1 py-2 rounded-xl text-xs font-medium transition-all duration-200 touch-manipulation",
                activeTab === item.id
                  ? "text-primary"
                  : "text-muted-foreground"
              )}
            >
              <item.icon className={cn(
                "w-5 h-5 transition-transform",
                activeTab === item.id && "scale-110"
              )} />
              <span className="text-[10px]">{item.label}</span>
            </button>
          ))}
        </div>
      </nav>
    </div>
  );
};

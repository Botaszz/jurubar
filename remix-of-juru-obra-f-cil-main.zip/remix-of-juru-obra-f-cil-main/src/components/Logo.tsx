import { Waves } from "lucide-react";

export const Logo = () => {
  return (
    <div className="flex items-center gap-2.5">
      <div className="relative">
        <div className="w-9 h-9 rounded-xl bg-gradient-to-br from-primary to-accent flex items-center justify-center">
          <Waves className="w-5 h-5 text-primary-foreground" />
        </div>
      </div>
      <span className="text-xl font-bold text-foreground tracking-tight">
        Juruá
      </span>
    </div>
  );
};

import { useState, useEffect } from "react";
import { Button } from "@/components/ui/button";
import { Download, X, Share } from "lucide-react";

interface BeforeInstallPromptEvent extends Event {
  prompt: () => Promise<void>;
  userChoice: Promise<{ outcome: "accepted" | "dismissed" }>;
}

export const PWAInstallPrompt = () => {
  const [deferredPrompt, setDeferredPrompt] = useState<BeforeInstallPromptEvent | null>(null);
  const [showPrompt, setShowPrompt] = useState(false);
  const [isIOS, setIsIOS] = useState(false);
  const [showIOSInstructions, setShowIOSInstructions] = useState(false);

  useEffect(() => {
    // Check if iOS
    const isIOSDevice = /iPad|iPhone|iPod/.test(navigator.userAgent) && !(window as any).MSStream;
    setIsIOS(isIOSDevice);

    // Check if already installed
    const isStandalone = window.matchMedia("(display-mode: standalone)").matches;
    const dismissed = localStorage.getItem("pwa-prompt-dismissed");

    if (isStandalone || dismissed) return;

    if (isIOSDevice) {
      // Show iOS instructions after a delay
      const timer = setTimeout(() => setShowPrompt(true), 3000);
      return () => clearTimeout(timer);
    }

    // Listen for beforeinstallprompt event (Chrome, Edge, etc.)
    const handler = (e: Event) => {
      e.preventDefault();
      setDeferredPrompt(e as BeforeInstallPromptEvent);
      setShowPrompt(true);
    };

    window.addEventListener("beforeinstallprompt", handler);
    return () => window.removeEventListener("beforeinstallprompt", handler);
  }, []);

  const handleInstall = async () => {
    if (!deferredPrompt) return;

    await deferredPrompt.prompt();
    const { outcome } = await deferredPrompt.userChoice;

    if (outcome === "accepted") {
      setShowPrompt(false);
    }
    setDeferredPrompt(null);
  };

  const handleDismiss = () => {
    setShowPrompt(false);
    localStorage.setItem("pwa-prompt-dismissed", "true");
  };

  if (!showPrompt) return null;

  return (
    <div className="fixed bottom-20 left-4 right-4 md:left-auto md:right-4 md:w-96 z-50 animate-slide-up">
      <div className="glass-effect rounded-2xl p-4 shadow-lg border border-primary/20">
        <button
          onClick={handleDismiss}
          className="absolute top-2 right-2 p-1 rounded-full hover:bg-muted transition-colors"
        >
          <X className="w-4 h-4 text-muted-foreground" />
        </button>

        <div className="flex items-start gap-3">
          <div className="w-12 h-12 rounded-xl bg-gradient-to-br from-primary to-accent flex items-center justify-center flex-shrink-0">
            <img 
              src="/pwa-icon-192.png" 
              alt="Juruá" 
              className="w-10 h-10 rounded-lg"
            />
          </div>

          <div className="flex-1 min-w-0">
            <h3 className="font-semibold text-foreground text-sm">
              Instalar Juruá
            </h3>
            <p className="text-xs text-muted-foreground mt-0.5">
              Adicione à tela inicial para acesso rápido
            </p>
          </div>
        </div>

        {isIOS ? (
          <div className="mt-3">
            {!showIOSInstructions ? (
              <Button
                onClick={() => setShowIOSInstructions(true)}
                className="w-full h-10 text-sm"
                size="sm"
              >
                <Share className="w-4 h-4 mr-2" />
                Como instalar
              </Button>
            ) : (
              <div className="space-y-2 text-xs text-muted-foreground bg-muted/50 rounded-lg p-3">
                <p className="font-medium text-foreground">Para instalar no iOS:</p>
                <ol className="list-decimal list-inside space-y-1">
                  <li>Toque no botão <Share className="w-3 h-3 inline mx-1" /> Compartilhar</li>
                  <li>Role e toque em "Adicionar à Tela de Início"</li>
                  <li>Toque em "Adicionar" para confirmar</li>
                </ol>
              </div>
            )}
          </div>
        ) : (
          <Button
            onClick={handleInstall}
            className="w-full mt-3 h-10 text-sm"
            size="sm"
          >
            <Download className="w-4 h-4 mr-2" />
            Instalar agora
          </Button>
        )}
      </div>
    </div>
  );
};

import { Button } from '@/components/ui/button';
import { Card, CardContent } from '@/components/ui/card';
import { Clock, LogOut } from 'lucide-react';
import { useAuth } from '@/contexts/AuthContext';
import juruaLogo from '@/assets/jurua-logo.png';

export const PendingApprovalPage = () => {
  const { signOut, profile } = useAuth();

  return (
    <div className="min-h-screen bg-background flex flex-col items-center justify-center px-4">
      <div className="flex flex-col items-center mb-8">
        <div className="w-20 h-20 rounded-full overflow-hidden mb-4 shadow-lg border-4 border-primary">
          <img
            src={juruaLogo}
            alt="Juruá Logo"
            className="w-full h-full object-cover scale-125"
          />
        </div>
        <h1 className="text-3xl font-bold text-foreground tracking-wide">JURUÁ</h1>
        <p className="text-primary text-sm tracking-widest mt-1">ESTALEIRO & NAVEGAÇÃO</p>
      </div>

      <Card className="w-full max-w-md bg-card/80 backdrop-blur-sm border-border/50">
        <CardContent className="p-8 text-center">
          <div className="w-16 h-16 mx-auto bg-warning/20 rounded-full flex items-center justify-center mb-4">
            <Clock className="w-8 h-8 text-warning" />
          </div>
          
          <h2 className="text-xl font-bold text-foreground mb-2">
            Aguardando Aprovação
          </h2>
          
          <p className="text-muted-foreground mb-6">
            Seu cadastro foi realizado com sucesso! O administrador precisa aprovar seu acesso antes que você possa utilizar o sistema.
          </p>

          <div className="bg-secondary/50 rounded-lg p-4 mb-6">
            <p className="text-sm text-muted-foreground">Logado como:</p>
            <p className="font-medium text-foreground">{profile?.email}</p>
          </div>

          <Button
            variant="outline"
            onClick={signOut}
            className="w-full"
          >
            <LogOut className="w-4 h-4 mr-2" />
            Sair
          </Button>
        </CardContent>
      </Card>

      <p className="text-muted-foreground text-xs mt-8">
        © 2025 Juruá Estaleiro & Navegação. Todos os direitos reservados.
      </p>
    </div>
  );
};

import { useState } from "react";
import { 
  Plus, 
  FileDown, 
  Mail, 
  Download,
  Sun,
  Cloud,
  CloudRain,
  Trash2,
  MapPin,
  CalendarDays
} from "lucide-react";
import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from "@/components/ui/dialog";
import {
  Popover,
  PopoverContent,
  PopoverTrigger,
} from "@/components/ui/popover";
import { Calendar } from "@/components/ui/calendar";
import { RDOData, CronogramaItem } from "@/types/rdo";
import { downloadPDF, getPDFBlob } from "@/utils/pdfGenerator";
import { format } from "date-fns";
import { ptBR } from "date-fns/locale";
import { cn } from "@/lib/utils";
import { useToast } from "@/hooks/use-toast";

interface RDOPageProps {
  rdos: RDOData[];
  setRdos: (rdos: RDOData[]) => void;
  cronograma: CronogramaItem[];
}

export const RDOPage = ({ rdos, setRdos, cronograma }: RDOPageProps) => {
  const { toast } = useToast();
  const [dialogOpen, setDialogOpen] = useState(false);
  const [emailDialogOpen, setEmailDialogOpen] = useState(false);
  const [selectedRDO, setSelectedRDO] = useState<RDOData | null>(null);
  const [emailAddress, setEmailAddress] = useState("");
  const [dateApresentacao, setDateApresentacao] = useState<Date>();
  const [dateAcuracidade, setDateAcuracidade] = useState<Date>();
  
  const [formData, setFormData] = useState<Partial<RDOData>>({
    localObra: "",
    obra: "",
    responsavel: "",
    clima: "",
    horaInicio: "",
    horaFim: "",
    atividades: {
      montagem: "",
      soldagem: "",
      acabamentos: "",
    },
    observacoes: "",
  });

  const handleCreateRDO = () => {
    if (!formData.obra || !dateApresentacao) {
      toast({
        title: "Erro",
        description: "Preencha os campos obrigatórios",
        variant: "destructive",
      });
      return;
    }

    const newRDO: RDOData = {
      id: Date.now().toString(),
      dataApresentacao: dateApresentacao ? format(dateApresentacao, "dd/MM/yyyy") : "",
      dataAcuracidade: dateAcuracidade ? format(dateAcuracidade, "dd/MM/yyyy") : "",
      horaInicio: formData.horaInicio || "",
      horaFim: formData.horaFim || "",
      localObra: formData.localObra || "",
      obra: formData.obra || "",
      responsavel: formData.responsavel || "",
      clima: formData.clima || "",
      atividades: formData.atividades || { montagem: "", soldagem: "", acabamentos: "" },
      observacoes: formData.observacoes || "",
      createdAt: new Date(),
    };

    setRdos([...rdos, newRDO]);
    setDialogOpen(false);
    resetForm();
    
    toast({
      title: "Sucesso!",
      description: "RDO criado com sucesso",
    });
  };

  const resetForm = () => {
    setFormData({
      localObra: "",
      obra: "",
      responsavel: "",
      clima: "",
      horaInicio: "",
      horaFim: "",
      atividades: { montagem: "", soldagem: "", acabamentos: "" },
      observacoes: "",
    });
    setDateApresentacao(undefined);
    setDateAcuracidade(undefined);
  };

  const handleExportPDF = (rdo: RDOData) => {
    downloadPDF(rdo, cronograma);
    toast({ title: "PDF Exportado!" });
  };

  const handleDownloadPDF = (rdo: RDOData) => {
    const blob = getPDFBlob(rdo, cronograma);
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `RDO_${rdo.obra}_${rdo.dataApresentacao}.pdf`;
    document.body.appendChild(a);
    a.click();
    document.body.removeChild(a);
    URL.revokeObjectURL(url);
    toast({ title: "Download Concluído!" });
  };

  const handleEmailClick = (rdo: RDOData) => {
    setSelectedRDO(rdo);
    setEmailDialogOpen(true);
  };

  const handleSendEmail = () => {
    if (!emailAddress || !selectedRDO) {
      toast({ title: "Erro", description: "Digite um e-mail válido", variant: "destructive" });
      return;
    }
    const subject = encodeURIComponent(`RDO - ${selectedRDO.obra} - ${selectedRDO.dataApresentacao}`);
    const body = encodeURIComponent(`Segue em anexo o RDO da obra ${selectedRDO.obra}.\n\nData: ${selectedRDO.dataApresentacao}\nResponsável: ${selectedRDO.responsavel}\n\nAtenciosamente,\nJuruá`);
    handleDownloadPDF(selectedRDO);
    window.open(`mailto:${emailAddress}?subject=${subject}&body=${body}`, '_blank');
    setEmailDialogOpen(false);
    setEmailAddress("");
    setSelectedRDO(null);
    toast({ title: "E-mail preparado!", description: "Anexe o PDF ao e-mail." });
  };

  const handleDeleteRDO = (id: string) => {
    setRdos(rdos.filter(rdo => rdo.id !== id));
    toast({ title: "RDO Excluído" });
  };

  const getClimaIcon = (clima: string) => {
    switch (clima) {
      case "ensolarado": return <Sun className="w-4 h-4 text-amber-400" />;
      case "nublado": return <Cloud className="w-4 h-4 text-muted-foreground" />;
      case "chuvoso": return <CloudRain className="w-4 h-4 text-primary" />;
      default: return null;
    }
  };

  return (
    <div className="space-y-4 animate-fade-in pb-20 md:pb-0">
      {/* Header */}
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-2xl font-bold text-foreground">RDO</h1>
          <p className="text-muted-foreground text-sm">Registro Diário de Obras</p>
        </div>
        
        <Dialog open={dialogOpen} onOpenChange={setDialogOpen}>
          <DialogTrigger asChild>
            <Button size="sm" className="bg-primary text-primary-foreground hover:bg-primary/90 rounded-xl touch-manipulation">
              <Plus className="w-4 h-4 mr-1.5" />
              Criar
            </Button>
          </DialogTrigger>
          <DialogContent className="max-w-lg max-h-[85vh] overflow-y-auto glass-dark border-border/30 mx-3">
            <DialogHeader>
              <DialogTitle className="text-lg font-bold text-foreground">Novo RDO</DialogTitle>
            </DialogHeader>
            
            <div className="space-y-4 py-2">
              {/* Datas */}
              <div className="grid grid-cols-2 gap-3">
                <div className="space-y-1.5">
                  <Label className="text-foreground text-xs">Data de Apresentação *</Label>
                  <Popover>
                    <PopoverTrigger asChild>
                      <Button
                        variant="outline"
                        className={cn(
                          "w-full justify-start text-left font-normal bg-secondary/50 border-border/30 h-10 text-sm",
                          !dateApresentacao && "text-muted-foreground"
                        )}
                      >
                        <CalendarDays className="w-4 h-4 mr-2 opacity-50" />
                        {dateApresentacao ? format(dateApresentacao, "dd/MM/yy", { locale: ptBR }) : "Selecione"}
                      </Button>
                    </PopoverTrigger>
                    <PopoverContent className="w-auto p-0 glass-dark border-border/30" align="start">
                      <Calendar
                        mode="single"
                        selected={dateApresentacao}
                        onSelect={setDateApresentacao}
                        locale={ptBR}
                        className="pointer-events-auto"
                      />
                    </PopoverContent>
                  </Popover>
                </div>
                
                <div className="space-y-1.5">
                  <Label className="text-foreground text-xs">Data de Acuracidade</Label>
                  <Popover>
                    <PopoverTrigger asChild>
                      <Button
                        variant="outline"
                        className={cn(
                          "w-full justify-start text-left font-normal bg-secondary/50 border-border/30 h-10 text-sm",
                          !dateAcuracidade && "text-muted-foreground"
                        )}
                      >
                        <CalendarDays className="w-4 h-4 mr-2 opacity-50" />
                        {dateAcuracidade ? format(dateAcuracidade, "dd/MM/yy", { locale: ptBR }) : "Selecione"}
                      </Button>
                    </PopoverTrigger>
                    <PopoverContent className="w-auto p-0 glass-dark border-border/30" align="start">
                      <Calendar
                        mode="single"
                        selected={dateAcuracidade}
                        onSelect={setDateAcuracidade}
                        locale={ptBR}
                        className="pointer-events-auto"
                      />
                    </PopoverContent>
                  </Popover>
                </div>
              </div>

              {/* Horários */}
              <div className="grid grid-cols-2 gap-3">
                <div className="space-y-1.5">
                  <Label className="text-foreground text-xs">Hora Início</Label>
                  <Input
                    type="time"
                    value={formData.horaInicio}
                    onChange={(e) => setFormData({ ...formData, horaInicio: e.target.value })}
                    className="bg-secondary/50 border-border/30 h-10"
                  />
                </div>
                <div className="space-y-1.5">
                  <Label className="text-foreground text-xs">Hora Fim</Label>
                  <Input
                    type="time"
                    value={formData.horaFim}
                    onChange={(e) => setFormData({ ...formData, horaFim: e.target.value })}
                    className="bg-secondary/50 border-border/30 h-10"
                  />
                </div>
              </div>

              {/* Local e Obra */}
              <div className="space-y-1.5">
                <Label className="text-foreground text-xs">Local da Obra</Label>
                <Input
                  placeholder="Ex: Rua das Flores, 123"
                  value={formData.localObra}
                  onChange={(e) => setFormData({ ...formData, localObra: e.target.value })}
                  className="bg-secondary/50 border-border/30 h-10"
                />
              </div>

              <div className="space-y-1.5">
                <Label className="text-foreground text-xs">Obra *</Label>
                <Input
                  placeholder="Nome da obra"
                  value={formData.obra}
                  onChange={(e) => setFormData({ ...formData, obra: e.target.value })}
                  className="bg-secondary/50 border-border/30 h-10"
                />
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div className="space-y-1.5">
                  <Label className="text-foreground text-xs">Responsável</Label>
                  <Input
                    placeholder="Nome"
                    value={formData.responsavel}
                    onChange={(e) => setFormData({ ...formData, responsavel: e.target.value })}
                    className="bg-secondary/50 border-border/30 h-10"
                  />
                </div>
                <div className="space-y-1.5">
                  <Label className="text-foreground text-xs">Clima</Label>
                  <Select
                    value={formData.clima}
                    onValueChange={(value) => setFormData({ ...formData, clima: value })}
                  >
                    <SelectTrigger className="bg-secondary/50 border-border/30 h-10">
                      <SelectValue placeholder="Selecione" />
                    </SelectTrigger>
                    <SelectContent className="glass-dark border-border/30">
                      <SelectItem value="ensolarado">☀️ Ensolarado</SelectItem>
                      <SelectItem value="nublado">☁️ Nublado</SelectItem>
                      <SelectItem value="chuvoso">🌧️ Chuvoso</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
              </div>

              {/* Atividades */}
              <div className="space-y-3">
                <Label className="text-foreground text-sm font-semibold">Atividades</Label>
                
                <div className="space-y-1.5">
                  <Label className="text-muted-foreground text-xs">Montagem</Label>
                  <Textarea
                    placeholder="Descreva..."
                    value={formData.atividades?.montagem}
                    onChange={(e) => setFormData({ 
                      ...formData, 
                      atividades: { ...formData.atividades!, montagem: e.target.value }
                    })}
                    className="bg-secondary/50 border-border/30 min-h-[60px] text-sm"
                  />
                </div>

                <div className="space-y-1.5">
                  <Label className="text-muted-foreground text-xs">Soldagem</Label>
                  <Textarea
                    placeholder="Descreva..."
                    value={formData.atividades?.soldagem}
                    onChange={(e) => setFormData({ 
                      ...formData, 
                      atividades: { ...formData.atividades!, soldagem: e.target.value }
                    })}
                    className="bg-secondary/50 border-border/30 min-h-[60px] text-sm"
                  />
                </div>

                <div className="space-y-1.5">
                  <Label className="text-muted-foreground text-xs">Acabamentos</Label>
                  <Textarea
                    placeholder="Descreva..."
                    value={formData.atividades?.acabamentos}
                    onChange={(e) => setFormData({ 
                      ...formData, 
                      atividades: { ...formData.atividades!, acabamentos: e.target.value }
                    })}
                    className="bg-secondary/50 border-border/30 min-h-[60px] text-sm"
                  />
                </div>
              </div>

              {/* Observações */}
              <div className="space-y-1.5">
                <Label className="text-foreground text-xs">Observações</Label>
                <Textarea
                  placeholder="Observações gerais..."
                  value={formData.observacoes}
                  onChange={(e) => setFormData({ ...formData, observacoes: e.target.value })}
                  className="bg-secondary/50 border-border/30 min-h-[70px] text-sm"
                />
              </div>

              <Button 
                onClick={handleCreateRDO}
                className="w-full bg-primary text-primary-foreground hover:bg-primary/90 h-11 rounded-xl"
              >
                Criar RDO
              </Button>
            </div>
          </DialogContent>
        </Dialog>
      </div>

      {/* Email Dialog */}
      <Dialog open={emailDialogOpen} onOpenChange={setEmailDialogOpen}>
        <DialogContent className="glass-dark border-border/30 mx-3">
          <DialogHeader>
            <DialogTitle className="text-foreground">Enviar por E-mail</DialogTitle>
          </DialogHeader>
          <div className="space-y-4 py-2">
            <div className="space-y-1.5">
              <Label className="text-foreground text-xs">E-mail do destinatário</Label>
              <Input
                type="email"
                placeholder="exemplo@email.com"
                value={emailAddress}
                onChange={(e) => setEmailAddress(e.target.value)}
                className="bg-secondary/50 border-border/30 h-10"
              />
            </div>
            <Button 
              onClick={handleSendEmail}
              className="w-full bg-primary text-primary-foreground hover:bg-primary/90 h-11 rounded-xl"
            >
              <Mail className="w-4 h-4 mr-2" />
              Preparar E-mail
            </Button>
          </div>
        </DialogContent>
      </Dialog>

      {/* RDO List */}
      {rdos.length === 0 ? (
        <Card className="glass-effect border-border/30">
          <CardContent className="py-12 text-center">
            <div className="w-14 h-14 mx-auto mb-3 rounded-2xl bg-primary/10 flex items-center justify-center">
              <Plus className="w-7 h-7 text-primary" />
            </div>
            <h3 className="text-lg font-semibold text-foreground mb-1">Nenhum RDO</h3>
            <p className="text-muted-foreground text-sm">Clique em "Criar" para começar</p>
          </CardContent>
        </Card>
      ) : (
        <div className="space-y-3">
          {rdos.map((rdo, index) => (
            <Card 
              key={rdo.id}
              className="glass-effect border-border/30 overflow-hidden transition-all duration-200 active:scale-[0.99] touch-manipulation"
              style={{ animationDelay: `${index * 50}ms` }}
            >
              <CardContent className="p-4">
                <div className="flex items-start justify-between mb-3">
                  <div className="flex items-start gap-3">
                    <div className="p-2 rounded-xl bg-primary/10">
                      <MapPin className="w-4 h-4 text-primary" />
                    </div>
                    <div>
                      <h3 className="font-semibold text-foreground text-sm">{rdo.obra}</h3>
                      <p className="text-xs text-muted-foreground">{rdo.localObra || "Local não informado"}</p>
                    </div>
                  </div>
                  <div className="flex items-center gap-1.5">
                    {getClimaIcon(rdo.clima)}
                    <span className="text-xs text-muted-foreground">{rdo.dataApresentacao}</span>
                  </div>
                </div>
                
                <div className="flex flex-wrap gap-1.5 mb-3">
                  <span className="px-2 py-1 rounded-lg text-[10px] font-medium bg-primary/10 text-primary">
                    {rdo.horaInicio} - {rdo.horaFim}
                  </span>
                  <span className="px-2 py-1 rounded-lg text-[10px] font-medium bg-secondary text-muted-foreground">
                    {rdo.responsavel}
                  </span>
                </div>
                
                <div className="flex gap-2 pt-3 border-t border-border/30">
                  <Button
                    size="sm"
                    variant="ghost"
                    onClick={() => handleExportPDF(rdo)}
                    className="flex-1 h-9 text-xs hover:bg-secondary/50"
                  >
                    <FileDown className="w-3.5 h-3.5 mr-1.5" />
                    PDF
                  </Button>
                  <Button
                    size="sm"
                    variant="ghost"
                    onClick={() => handleEmailClick(rdo)}
                    className="flex-1 h-9 text-xs hover:bg-secondary/50"
                  >
                    <Mail className="w-3.5 h-3.5 mr-1.5" />
                    E-mail
                  </Button>
                  <Button
                    size="sm"
                    variant="ghost"
                    onClick={() => handleDownloadPDF(rdo)}
                    className="flex-1 h-9 text-xs hover:bg-secondary/50"
                  >
                    <Download className="w-3.5 h-3.5 mr-1.5" />
                    Baixar
                  </Button>
                  <Button
                    size="sm"
                    variant="ghost"
                    onClick={() => handleDeleteRDO(rdo.id)}
                    className="h-9 px-2 text-destructive hover:bg-destructive/10"
                  >
                    <Trash2 className="w-3.5 h-3.5" />
                  </Button>
                </div>
              </CardContent>
            </Card>
          ))}
        </div>
      )}
    </div>
  );
};

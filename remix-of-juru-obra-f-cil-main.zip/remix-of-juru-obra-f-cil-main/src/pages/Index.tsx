import { useState } from "react";
import { Layout } from "@/components/Layout";
import { Dashboard } from "@/components/Dashboard";
import { RDOPage } from "@/components/RDOPage";
import { CronogramaPage } from "@/components/CronogramaPage";
import { HoraHomemPage } from "@/components/HoraHomemPage";
import { PWAInstallPrompt } from "@/components/PWAInstallPrompt";
import { AuthPageNew } from "@/components/AuthPageNew";
import { PendingApprovalPage } from "@/components/PendingApprovalPage";
import { AdminPage } from "@/components/AdminPage";
import { useAuth } from "@/contexts/AuthContext";
import { RDOData, CronogramaItem, ObraHH } from "@/types/rdo";
import { Loader2 } from "lucide-react";

const Index = () => {
  const { user, loading, isApproved, isAdmin, isSuperAdmin } = useAuth();
  const [activeTab, setActiveTab] = useState("dashboard");
  const [rdos, setRdos] = useState<RDOData[]>([]);
  const [cronograma, setCronograma] = useState<CronogramaItem[]>([]);
  const [obras, setObras] = useState<ObraHH[]>([]);

  if (loading) {
    return (
      <div className="min-h-screen bg-background flex items-center justify-center">
        <Loader2 className="w-8 h-8 animate-spin text-primary" />
      </div>
    );
  }

  if (!user) {
    return <AuthPageNew />;
  }

  if (!isApproved && !isAdmin) {
    return <PendingApprovalPage />;
  }

  const renderContent = () => {
    switch (activeTab) {
      case "dashboard":
        return <Dashboard rdos={rdos} cronograma={cronograma} obras={obras} />;
      case "rdo":
        return <RDOPage rdos={rdos} setRdos={setRdos} cronograma={cronograma} />;
      case "cronograma":
        return <CronogramaPage cronograma={cronograma} setCronograma={setCronograma} />;
      case "hora-homem":
        return <HoraHomemPage obras={obras} setObras={setObras} />;
      case "admin":
        return isAdmin ? <AdminPage isSuperAdmin={isSuperAdmin} /> : <Dashboard rdos={rdos} cronograma={cronograma} obras={obras} />;
      default:
        return <Dashboard rdos={rdos} cronograma={cronograma} obras={obras} />;
    }
  };

  return (
    <Layout activeTab={activeTab} onTabChange={setActiveTab} isAdmin={isAdmin}>
      {renderContent()}
      <PWAInstallPrompt />
    </Layout>
  );
};

export default Index;

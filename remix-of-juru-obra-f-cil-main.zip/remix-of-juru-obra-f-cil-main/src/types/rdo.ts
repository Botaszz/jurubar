export interface RDOData {
  id: string;
  dataApresentacao: string;
  dataAcuracidade: string;
  horaInicio: string;
  horaFim: string;
  localObra: string;
  obra: string;
  responsavel: string;
  clima: string;
  atividades: {
    montagem: string;
    soldagem: string;
    acabamentos: string;
  };
  observacoes: string;
  createdAt: Date;
  // New fields for submission
  status?: 'rascunho' | 'pendente' | 'aprovado' | 'reprovado' | 'refazer';
  documentId?: string;
}

export interface CronogramaItem {
  id: string;
  atividade: string;
  dataInicio: string;
  dataFim: string;
  responsavel: string;
  status: 'pendente' | 'em_andamento' | 'concluido';
  progresso: number;
}

export interface HHRegistro {
  id: string;
  data: string;
  horas: number;
  minutos: number;
  montadores: number;
  ajudantes: number;
  soldadores: number;
  lixadores: number;
  totalHH: number; // Total in decimal hours
  totalHHFormatted: string; // Formatted as "Xh Ymin"
  atividade: string;
  local: string;
  categoria: 'montador-ajudante' | 'soldador-lixador';
}

export interface ObraHH {
  id: string;
  nome: string;
  local: string;
  registros: HHRegistro[];
  createdAt: Date;
  // New fields for submission
  status?: 'rascunho' | 'pendente' | 'aprovado' | 'reprovado' | 'refazer';
  documentId?: string;
}

export interface HoraHomemData {
  id: string;
  data: string;
  funcionarios: {
    montador: { nome: string; horas: number }[];
    ajudante: { nome: string; horas: number }[];
    soldador: { nome: string; horas: number }[];
    lixador: { nome: string; horas: number }[];
  };
  totalHoras: number;
}

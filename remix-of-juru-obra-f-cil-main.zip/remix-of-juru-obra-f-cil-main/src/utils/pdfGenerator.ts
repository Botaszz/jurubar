import jsPDF from 'jspdf';
import autoTable from 'jspdf-autotable';
import { RDOData, CronogramaItem } from '@/types/rdo';

export const generateRDOPDF = (rdo: RDOData, cronograma: CronogramaItem[]) => {
  const doc = new jsPDF();
  
  // Page 1 - RDO
  // Header with blue gradient effect
  doc.setFillColor(26, 32, 44);
  doc.rect(0, 0, 210, 50, 'F');
  
  // Accent line
  doc.setFillColor(56, 189, 248);
  doc.rect(0, 50, 210, 2, 'F');
  
  // Logo text
  doc.setTextColor(255, 255, 255);
  doc.setFontSize(26);
  doc.setFont('helvetica', 'bold');
  doc.text('Juruá', 20, 30);
  
  // Subtitle
  doc.setFontSize(11);
  doc.setFont('helvetica', 'normal');
  doc.setTextColor(148, 163, 184);
  doc.text('Registro Diário de Obras', 20, 40);
  
  // Date badge
  doc.setFillColor(56, 189, 248);
  doc.roundedRect(140, 15, 55, 25, 4, 4, 'F');
  doc.setTextColor(26, 32, 44);
  doc.setFontSize(9);
  doc.text('Data de Apresentação', 145, 24);
  doc.setFontSize(11);
  doc.setFont('helvetica', 'bold');
  doc.text(rdo.dataApresentacao || '-', 145, 34);
  
  // Reset text color
  doc.setTextColor(30, 41, 59);
  
  // Info Section
  doc.setFontSize(13);
  doc.setFont('helvetica', 'bold');
  doc.text('Informações da Obra', 20, 68);
  
  doc.setDrawColor(56, 189, 248);
  doc.setLineWidth(0.5);
  doc.line(20, 72, 190, 72);
  
  // Info table
  autoTable(doc, {
    startY: 78,
    head: [],
    body: [
      ['Local da Obra:', rdo.localObra || '-', 'Data de Acuracidade:', rdo.dataAcuracidade || '-'],
      ['Obra:', rdo.obra || '-', 'Responsável:', rdo.responsavel || '-'],
      ['Hora Início:', rdo.horaInicio || '-', 'Hora Fim:', rdo.horaFim || '-'],
      ['Clima:', rdo.clima || '-', '', ''],
    ],
    theme: 'plain',
    styles: {
      fontSize: 10,
      cellPadding: 4,
      textColor: [30, 41, 59],
    },
    columnStyles: {
      0: { fontStyle: 'bold', cellWidth: 40, textColor: [100, 116, 139] },
      1: { cellWidth: 55 },
      2: { fontStyle: 'bold', cellWidth: 45, textColor: [100, 116, 139] },
      3: { cellWidth: 50 },
    },
  });
  
  // Activities Section
  const finalY = (doc as any).lastAutoTable.finalY + 12;
  doc.setFontSize(13);
  doc.setFont('helvetica', 'bold');
  doc.text('Atividades', 20, finalY);
  doc.line(20, finalY + 4, 190, finalY + 4);
  
  autoTable(doc, {
    startY: finalY + 10,
    head: [['Tipo', 'Descrição']],
    body: [
      ['Montagem', rdo.atividades.montagem || '-'],
      ['Soldagem', rdo.atividades.soldagem || '-'],
      ['Acabamentos', rdo.atividades.acabamentos || '-'],
    ],
    theme: 'striped',
    headStyles: {
      fillColor: [26, 32, 44],
      textColor: [255, 255, 255],
      fontStyle: 'bold',
      fontSize: 10,
    },
    alternateRowStyles: {
      fillColor: [241, 245, 249],
    },
    styles: {
      fontSize: 10,
      cellPadding: 6,
      textColor: [30, 41, 59],
    },
  });
  
  // Observations
  const activitiesY = (doc as any).lastAutoTable.finalY + 12;
  doc.setFontSize(13);
  doc.setFont('helvetica', 'bold');
  doc.text('Observações', 20, activitiesY);
  doc.line(20, activitiesY + 4, 190, activitiesY + 4);
  
  doc.setFontSize(10);
  doc.setFont('helvetica', 'normal');
  const splitObs = doc.splitTextToSize(rdo.observacoes || 'Nenhuma observação', 170);
  doc.text(splitObs, 20, activitiesY + 14);
  
  // Footer
  doc.setFillColor(26, 32, 44);
  doc.rect(0, 282, 210, 15, 'F');
  doc.setTextColor(148, 163, 184);
  doc.setFontSize(8);
  doc.text(`Gerado por Juruá - ${new Date().toLocaleDateString('pt-BR')}`, 20, 291);
  doc.text('Página 1 de 2', 175, 291);
  
  // Page 2 - Cronograma
  doc.addPage();
  
  // Header
  doc.setFillColor(26, 32, 44);
  doc.rect(0, 0, 210, 50, 'F');
  doc.setFillColor(56, 189, 248);
  doc.rect(0, 50, 210, 2, 'F');
  
  doc.setTextColor(255, 255, 255);
  doc.setFontSize(26);
  doc.setFont('helvetica', 'bold');
  doc.text('Juruá', 20, 30);
  
  doc.setFontSize(11);
  doc.setFont('helvetica', 'normal');
  doc.setTextColor(148, 163, 184);
  doc.text('Cronograma de Atividades', 20, 40);
  
  // Obra info
  doc.setFillColor(56, 189, 248);
  doc.roundedRect(140, 15, 55, 25, 4, 4, 'F');
  doc.setTextColor(26, 32, 44);
  doc.setFontSize(9);
  doc.text('Obra', 145, 24);
  doc.setFontSize(10);
  doc.setFont('helvetica', 'bold');
  const obraText = doc.splitTextToSize(rdo.obra || '-', 50);
  doc.text(obraText, 145, 33);
  
  // Reset
  doc.setTextColor(30, 41, 59);
  
  // Cronograma title
  doc.setFontSize(13);
  doc.setFont('helvetica', 'bold');
  doc.text('Atividades do Cronograma', 20, 68);
  doc.setDrawColor(56, 189, 248);
  doc.line(20, 72, 190, 72);
  
  // Cronograma table
  if (cronograma.length > 0) {
    autoTable(doc, {
      startY: 78,
      head: [['Atividade', 'Data Início', 'Data Fim', 'Responsável', 'Status', 'Progresso']],
      body: cronograma.map(item => [
        item.atividade,
        item.dataInicio,
        item.dataFim,
        item.responsavel,
        item.status === 'concluido' ? 'Concluído' : item.status === 'em_andamento' ? 'Em Andamento' : 'Pendente',
        `${item.progresso}%`,
      ]),
      theme: 'striped',
      headStyles: {
        fillColor: [26, 32, 44],
        textColor: [255, 255, 255],
        fontStyle: 'bold',
        fontSize: 9,
      },
      alternateRowStyles: {
        fillColor: [241, 245, 249],
      },
      styles: {
        fontSize: 9,
        cellPadding: 5,
        textColor: [30, 41, 59],
      },
      columnStyles: {
        0: { cellWidth: 45 },
        4: { cellWidth: 25 },
        5: { cellWidth: 22, halign: 'center' },
      },
    });
  } else {
    doc.setFontSize(10);
    doc.setFont('helvetica', 'italic');
    doc.setTextColor(100, 116, 139);
    doc.text('Nenhuma atividade cadastrada no cronograma', 20, 88);
  }
  
  // Footer Page 2
  doc.setFillColor(26, 32, 44);
  doc.rect(0, 282, 210, 15, 'F');
  doc.setTextColor(148, 163, 184);
  doc.setFontSize(8);
  doc.text(`Gerado por Juruá - ${new Date().toLocaleDateString('pt-BR')}`, 20, 291);
  doc.text('Página 2 de 2', 175, 291);
  
  return doc;
};

export const downloadPDF = (rdo: RDOData, cronograma: CronogramaItem[]) => {
  const doc = generateRDOPDF(rdo, cronograma);
  doc.save(`RDO_${rdo.obra}_${rdo.dataApresentacao}.pdf`);
};

export const getPDFBlob = (rdo: RDOData, cronograma: CronogramaItem[]): Blob => {
  const doc = generateRDOPDF(rdo, cronograma);
  return doc.output('blob');
};

import { createClient } from 'https://esm.sh/@supabase/supabase-js@2'

const corsHeaders = {
  'Access-Control-Allow-Origin': '*',
  'Access-Control-Allow-Headers': 'authorization, x-client-info, apikey, content-type',
}

Deno.serve(async (req) => {
  if (req.method === 'OPTIONS') {
    return new Response(null, { headers: corsHeaders })
  }

  try {
    const { code, userId } = await req.json()

    if (!code || typeof code !== 'string') {
      return new Response(
        JSON.stringify({ valid: false, error: 'Código inválido' }),
        { status: 400, headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
      )
    }

    const supabaseUrl = Deno.env.get('SUPABASE_URL')!
    const supabaseServiceKey = Deno.env.get('SUPABASE_SERVICE_ROLE_KEY')!
    
    const supabase = createClient(supabaseUrl, supabaseServiceKey)

    // Verify the code exists, is active, and hasn't been used
    const { data: codeData, error: codeError } = await supabase
      .from('registration_codes')
      .select('id, code, is_active, used_by')
      .eq('code', code.trim().toUpperCase())
      .eq('is_active', true)
      .is('used_by', null)
      .maybeSingle()

    if (codeError) {
      console.error('Error verifying code:', codeError)
      return new Response(
        JSON.stringify({ valid: false, error: 'Erro ao verificar código' }),
        { status: 500, headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
      )
    }

    if (!codeData) {
      return new Response(
        JSON.stringify({ valid: false, error: 'Código de registro inválido ou já utilizado' }),
        { status: 200, headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
      )
    }

    // If userId is provided, mark the code as used
    if (userId) {
      const { error: updateError } = await supabase
        .from('registration_codes')
        .update({
          used_by: userId,
          used_at: new Date().toISOString(),
        })
        .eq('id', codeData.id)

      if (updateError) {
        console.error('Error marking code as used:', updateError)
        return new Response(
          JSON.stringify({ valid: false, error: 'Erro ao registrar uso do código' }),
          { status: 500, headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
        )
      }
    }

    return new Response(
      JSON.stringify({ valid: true, codeId: codeData.id }),
      { status: 200, headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
    )
  } catch (error) {
    console.error('Unexpected error:', error)
    return new Response(
      JSON.stringify({ valid: false, error: 'Erro interno do servidor' }),
      { status: 500, headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
    )
  }
})
